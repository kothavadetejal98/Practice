package com.cts.graphql.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.graphql.repo.Samplerequestrepo;
import com.cts.graphql.request.SampleRequest;
import com.cts.graphql.response.SampleResponse;






@Service
public class Sampleservice {
	@Autowired
	Samplerequestrepo repo;

	

	public SampleRequest getStudentById(String id) {
		
		return this.repo.findById(id).get();
	}
	
	
}

	
	
	


	
	
	
	
