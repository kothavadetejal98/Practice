package com.cts.graphql.response;



import javax.persistence.Entity;

import com.cts.graphql.request.SampleRequest;

@Entity
public class SampleResponse {

	private String id;
	private String firstName;
	private String lastName;

	public SampleResponse(SampleRequest studentById) {
		this.id = studentById.getId();
		this.firstName = studentById.getFirstName();
		this.lastName = studentById.getLastName();
	}

}
