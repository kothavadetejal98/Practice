package com.cts.graphql.query;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.cts.graphql.request.SampleRequest;
import com.cts.graphql.response.SampleResponse;
import com.cts.graphql.service.Sampleservice;











@Component
public class Query implements GraphQLQueryResolver {
	@Autowired
	Sampleservice sampleservice;
	public String firstquery() {
		return "firstquery";
	}
	public String secondquery() {
		return "secondquery";
	}
	
//	public String fullName(String firstName,String lastName) {
//		return firstName + "" + lastName;
//	}
	
	public String fullName(SampleRequest samplerequest) {
		return samplerequest.getId() + "" +  samplerequest.getFirstName() + "" + samplerequest.getLastName();
	}
	
	public SampleResponse getStudent (String id) {
		return new SampleResponse(sampleservice.getStudentById(id));
	}
	

	
	
	
	


}

