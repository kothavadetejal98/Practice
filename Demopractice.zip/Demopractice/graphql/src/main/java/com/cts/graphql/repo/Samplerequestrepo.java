package com.cts.graphql.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.graphql.request.SampleRequest;
import com.cts.graphql.response.SampleResponse;


@Repository
public interface Samplerequestrepo extends JpaRepository<SampleRequest,String> {



}
