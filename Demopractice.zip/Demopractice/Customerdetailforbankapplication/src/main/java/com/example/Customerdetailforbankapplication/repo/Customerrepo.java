package com.example.Customerdetailforbankapplication.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Customerdetailforbankapplication.entity.Customerinfo;

@Repository
public interface Customerrepo extends JpaRepository<Customerinfo,Integer> {

	void deleteById(String id);

	Optional<Customerinfo> findById(String id);

	Customerinfo save(Number number);

}
