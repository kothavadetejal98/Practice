package com.example.Customerdetailforbankapplication.controller;


class CustomercontrollerTests {
	

}
