package com.company;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Streamjava8 {
	public static void main(String[] args) {
		ArrayList<Integer> l= new ArrayList<Integer>();
		l.add(0);
		l.add(5);
		l.add(10);
		l.add(15);
		l.add(20);
		l.add(25);
		//List<ArrayList<Integer>> number=Arrays.asList(l);
		List<Integer> number1=l.stream().filter(i->i%2==0).collect(Collectors.toList());
		List<Integer> number2=l.stream().map(i->i+5).collect(Collectors.toList());
		System.out.println(number2);
		List<Integer> number3=l.stream().filter(i->i%2!=0).collect(Collectors.toList());
		System.out.println(number3);
		
				
		System.out.println(number1);
		
	}
	
	
	

}