package com.company;

public class CWH_09_Operator_presidence {

	public static void main(String[] args) {
//		int a=6/2-3*4;
//		System.out.println(a);
		
		float a=1;
		float b=4;
		float c=5;
		System.out.println(c);
		float d=b*b-(4*a*c)/(2*a);
		System.out.println(d);
		

	}

}
