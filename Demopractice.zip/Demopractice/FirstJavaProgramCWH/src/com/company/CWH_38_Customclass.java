package com.company;

public class CWH_38_Customclass {
	
	static class Employee{
		int id;
		int salary;
		String name;
		
		public void printdetails() {
			System.out.println("Id of employee is " + id );
			System.out.println("Name of employee is " + name );
			System.out.println("Salary of employee is " + salary);
		}
		
//		public int getsalary() {
//			return salary;
//		}
	}

	public static void main(String[] args) {
		System.out.println("This is a custom class");
		Employee harry=new Employee();
		harry.id=12;
		harry.name="John";
		harry.salary=1000;
		harry.printdetails();
//		int salary=harry.getsalary();
//		System.out.println(salary);

	}

}
