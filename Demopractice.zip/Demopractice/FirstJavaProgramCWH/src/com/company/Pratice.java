package com.company;

public class Pratice {
	static int a;
	static int b;
	
	public static void main(String[] args) {
		Pratice p=new Pratice();
		p.a=9;
		p.b=9;
		System.out.println(a+b);
	}

}



