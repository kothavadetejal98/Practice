package com.company;

public class Area {
	int perimeter(int x,int y) {
		return 2*(x+y);
	}
	  
	

	public static void main(String[] args) {
		Area obj=new Area();
		System.out.println(obj.perimeter(5, 9));

	}

}
