package com.company;

public class CWH_CH2_Ps_pr4 {

	public static void main(String[] args) {
	float v=8;
	float u=9;
	float a=7;
	float s=8;
	float result=((v*v)-(u*u))/(2*a*s);
	System.out.println(result);

	}

}
