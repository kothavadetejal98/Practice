package com.company;

public class CWH_26_Arrays {

	public static void main(String[] args) {
		//int[]  marks=new int[5];
		int[] marks= {98,99,97,96,94};
//		marks[0]=98;
//		marks[1]=99;
//		marks[2]=97;
//		marks[3]=96;
//		marks[4]=94;
		System.out.println(marks[4]);
		
	}

}

