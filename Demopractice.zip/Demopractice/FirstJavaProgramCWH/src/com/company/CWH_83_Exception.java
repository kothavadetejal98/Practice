package com.company;

import java.util.Scanner;

public class CWH_83_Exception {
	
	static class MyException extends Exception{
		@Override
		public String toString() {
			
			return super.toString() + "I am tostring()";
		}
		@Override
		public String getMessage() {
			
			return super.getMessage() + "I am getMessage()";
		}
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		
		
		if(a<99) {
			try {
				throw new MyException();
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
			
		}
	}

}
