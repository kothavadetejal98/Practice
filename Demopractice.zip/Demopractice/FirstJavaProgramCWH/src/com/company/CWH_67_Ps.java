package com.company;

public class CWH_67_Ps {
	
	class calculator{
		public void calculate(int a,int b) {
			System.out.println("Your result is" + a+b);
		}
		
	}
	class sccalculator{
		public void sccalculate(int a,int b) {
			System.out.println("Your result is" + Math.sin(a+b));
		}
		
	}
	class hybridcalculator{
		public void hybridcalculate(int a,int b) {
			System.out.println("Your result is" + Math.sin(a+b));

			System.out.println("Your result is" + (a+b));
		}
	}
	public static void main(String[] args) {
		System.out.println("This is main method");
	}

}
