package com.company;

public class CWH_CH4_Ps_pr1 {

	public static void main(String[] args) {
		//Question1
		int a=10;
		if(a==11) {
			System.out.println("I am 11");
		}
		else {
			System.out.println("I am not 11");
		}

	}

}
