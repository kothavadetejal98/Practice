package com.company;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public interface Javafeatures {

	public int square(int n);

	public static void main(String[] args) {
		// 1. lambda expression with functional interface
		Javafeatures i = n -> n * n;
		System.out.println(i.square(4));

		// 2. comparator in functional interface to check int comparison
		ArrayList<Integer> l = new ArrayList<>();
		l.add(3);
		l.add(18);
		l.add(2);
		Comparator<Integer> comp = (I1, I2) -> (I1 < I2) ? -1 : (I1 > I2) ? 1 : 0;
		Collections.sort(l, comp);
		System.out.println(l);

		// 3. comparator in functional interface for alphabetical order
		ArrayList<String> s = new ArrayList<>();
		s.add("Tejal");
		s.add("Jemes");
		s.add("Saj");
		Comparator<String> comp1 = (I1, I2) -> I1.compareTo(I2);
		Collections.sort(s, comp1);
		System.out.println(s);

		// 4.predefined functional interface
		
		// a.Predicate-check boolean condition
		Predicate<Integer> p = k -> k % 2 == 0;
		System.out.println(p.test(9));
		System.out.println(p.test(2));

		// b.Function-<I/P data type,o/p data type>
        Function<String,Integer> f=j->j.length();
        System.out.println(f.apply("Tejal"));
        
        //c. consumer-don't return anything jst take input and perform required operation
        Consumer<String> c=m-> System.out.println(m);
        c.accept("hello java");
        
         
        //d. Supplier-wont take any input
        Supplier<Date> d=()->new Date();
        System.out.println(d.get());
        
        //e.Bipredicate
        BiPredicate<Integer,Integer> n=(a,b)->(a+b)%2==0;
        System.out.println(n.test(10, 20));
        
        
        //f. Bifunction
        BiFunction<Integer,Integer,Integer> o=(u,j)->u*j;
        System.out.println(o.apply(4, 6));
        
        
        
        
        
	}

}
