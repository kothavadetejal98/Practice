package com.company;

public class CWH_21_Loops {

	public static void main(String[] args) {
//		//while loop
//		int i=1;
//		while(i<=100) {
//	
//		System.out.println(i);
//		i++;
//	}
//		//do while loop
//		int b=101;
//		do {
//			System.out.println(b);
//			b++;
//		}while(b<=100);
		
		//for loop
//		for(int i1=0;i1<=10;i1++) {
//			System.out.println(i1);
//		}
		
		//first n odd number using for loop
		//int n=5;
//		for(int i=0;i<5;i++) {
//			System.out.println(2*i+1);
//		}
		
//		for(int i=5;i>=0;i--) {
//			System.out.println(2*i+1);
//		}
		
		int n=10;
		for (int i=10;i>=0;i--) {
			System.out.println(i);
		}
		
	}

}
