package com.company;

import java.util.Scanner;

public class CWH_13_String {

	public static void main(String[] args) {
//		String string=new String("Harry");
//		String name="harry";
//		System.out.println(name);
		Scanner sc=new Scanner(System.in);
		String name1=sc.next();
		System.out.println(name1);

	}

}
