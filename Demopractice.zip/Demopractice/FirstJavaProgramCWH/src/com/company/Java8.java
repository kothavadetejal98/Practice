package com.company;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import com.company.Lambda1.demo;

public class Java8 {
	public static void main(String[] args) {
		
		
		//Predicate-Check condition and return boolean value
		Predicate<Integer> l=i->i%2==0;
		System.out.println(l.test(9));
		System.out.println(l.test(2));
		
		//Function-take input perform some operation and return result
		Function<Integer,Integer> f=i->i*i;
		System.out.println(f.apply(2));
		
//Consumer-accept some input and perform required operation and not required to	return anything
		Consumer<Integer> c=i->System.out.println(i);
		c.accept(8);
		
		//Supplier-just supply required object and it wont take any input
		Supplier<Date> s=()->new Date();
		System.out.println(s.get());
		
		//Stream
		Integer[] p= {1,2,3,4,5,6,7,8};
		List<Integer> number=Arrays.asList(1,2,3,4,5,6,7,8);
		List<Integer> number1=number.stream().filter(i->i>4).collect(Collectors.toList());
		int number2=number.stream().filter(i->i%2==0).mapToInt(Integer::intValue).sum();
		System.out.println(number2);
		System.out.println(number1);
		
		//Comparator
		ArrayList<String> s1=new ArrayList<String>();
		s1.add("Tejal");
		s1.add("John");
		Comparator<String> comp=(S1,S2)->S1.compareTo(S2);
		Collections.sort(s1,comp);
		System.out.println(s1);
		
		ArrayList<Integer> m=new ArrayList<Integer>();
		m.add(8);
		m.add(1);
		m.add(0);
		m.add(10);
		Comparator<Integer> c1=(i1,i2)->i1.compareTo(i2);
	    Collections.sort(m,c1);
	    System.out.println(m);
	    
	    ArrayList<Integer> l1=new ArrayList<>();
	    l1.add(0);
	    
	    
	    
	    
		
		
	
		
		
	
	}

}
