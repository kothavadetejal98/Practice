
package com.company;

public class CWH_27_Arrays {

	public static void main(String[] args) {
		int[] marks= {10,20,30,40};
		System.out.println(marks.length);
		System.out.println(marks[3]);
		
		//print array in reverse order
		for(int i=marks.length-1;i>=0;i--) {
			System.out.println(marks[i]);
		}
		
		//for each loop
		for(int element:marks) {
			System.out.println(element);
		}
		
	}

}
