package com.company;

public class CWH_85_Finally {
	public static int greet(){
		try{
			int a=9;
			int b=3;
			int c=a/b;
            return c;
		}
		catch(Exception e) {
			System.out.println(e);
		}
		finally {
			System.out.println("This is end of program");
		}
		return 0;
	}

	public static void main(String[] args) {
		int k= greet();
		System.out.println(k);
		int a=9;
		int b=8;
		while(true) {
			try {
				int c=a/b;
			}
			catch(Exception e) {
				System.out.println(e);
				break;
			}
			finally {
				System.out.println("I am a finally" + b);
			}
			b--;
			
		}
		
	
	}

}
