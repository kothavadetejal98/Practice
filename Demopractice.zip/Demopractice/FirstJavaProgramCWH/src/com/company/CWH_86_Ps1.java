package com.company;

import java.util.Scanner;

public class CWH_86_Ps1 {
	 static  class myexception extends Exception{
		  @Override
		public String toString() {
			
			return super.toString()+ "I am a tostring";
		}
		  private String getmessage() {
			  return super.getMessage()+ "I am a tomessage";
		}
	  }

	public static void main(String[] args) {
		boolean flag=true;
		int[] marks=new int[3];
		marks[0]=9;
		marks[1]=10;
		marks[2]=23;
		Scanner sc=new Scanner(System.in);
		int index=sc.nextInt();
		
		int i=0;
		
			try {
				
				System.out.println("The value of marks[index] is" + marks[index]);
				throw new myexception();
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
				System.out.println("Invalid index");
				
			}
		}
		

	}


