package com.company;

public class CWH_10_resultingdatatype {

	public static void main(String[] args) {
//		int x=60;
//		byte y=8;
//		short z=54;
//		long s=6544l;
//		double t=0.888;
//		float u=8.9f;
//		double m=t+u;
//		System.out.println(m);
		
		
		//Increment & decrement operator
//		int x=9;
//		System.out.println(++x); 
//		System.out.println(x);
//		System.out.println(x++);
//		System.out.println(++x);
		
		int y=7;
		int x=++y *8;
		System.out.println(x);
	}

}
