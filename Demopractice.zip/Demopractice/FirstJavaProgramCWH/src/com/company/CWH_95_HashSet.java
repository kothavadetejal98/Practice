package com.company;

import java.util.HashSet;

public class CWH_95_HashSet {

	public static void main(String[] args) {
		HashSet<Integer> ad1=new HashSet<>();
		ad1.add(9);
		ad1.add(7);
		ad1.add(10);
		System.out.println(ad1);

	}

}


