package com.company;

public class Lambda1 {
	@FunctionalInterface
	interface  demo{
		void meth1();
		
		}

	
	

	public static void main(String[] args) {
		demo i=()->System.out.println("meth1() method implementation");
		i.meth1();
		
	}

}
