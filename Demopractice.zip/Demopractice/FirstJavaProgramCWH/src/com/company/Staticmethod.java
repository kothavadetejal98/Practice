package com.company;

public interface Staticmethod {
	
	public static void m1() {
		System.out.println("main");
	}
	public static void main(String[] args) {
		Staticmethod.m1();
	}

}

