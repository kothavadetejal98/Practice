package com.company;

import com.company.CWH_38_Customclass.Employee;

public class Evalutaion_customclass {
	
	static class Size{
		int length;
		int breath;
		int area;
		
		
		public void printdetails() {
			System.out.println(area );
			
			
		}
		

	}

	public static void main(String[] args) {
		
		Size obj=new Size();
		obj.length=12;
		obj.breath=7;
		obj.area=obj.length+obj.breath;
		
		obj.printdetails();

	}

}

