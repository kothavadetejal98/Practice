package com.company;

public interface Defaultmethod {
	default void m1() {
		System.out.println("m1");
	}
public class test implements Defaultmethod{
	@Override
	public void m1() {
		System.out.println("my own implementation");
	}
}
public static void main(String[] args) {
		test t=new test();
		t.m1();

	}

	

}
