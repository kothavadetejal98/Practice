package com.company;

public class CWH_54_Interface {
	
	interface bicycle{
		int a=45;
		void applybrake(int decrement);
		void speedup(int increment);
	}
	
	static class avoncycle implements bicycle{
		
		
		void blowhorn() {
			System.out.println("horn");
		}
		public void applybrake(int decrement) {
			System.out.println("applying brake");
		}
		@Override
		public void speedup(int increment) {
			System.out.println("applying speedup");
			
		}
	}

	public static void main(String[] args) {
		avoncycle obj=new avoncycle();
		obj.applybrake(1);
		//You can create property in interface
		System.out.println(obj.a);
		//You cannot modified the properties in interface as they are final.
		
   
		

	}

}
