package com.company;

public class CWH_24_Break_Continue {
public static void main(String[] args) {
	for(int i=0;i<5;i++) {
		System.out.println(i);
		System.out.println("Java is a great");
		
		if(i==2) {
			System.out.println("Ending the loop");
			break;
		}
		if(i==1) {
			System.out.println("Ending loop1");
			continue;
		}
	}
}
}
