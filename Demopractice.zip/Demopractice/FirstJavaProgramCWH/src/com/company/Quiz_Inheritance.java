package com.company;

import com.company.Quiz_Inheritance.Animal.dog;

public class Quiz_Inheritance {
static class Animal{
	String pet;

	public String getPet() {
		return pet;
	}

	public void setPet(String pet) {
		this.pet = pet;
	}
	static class dog extends Animal{
		String bark;

		public String getBark() {
			return bark;
		}

		public void setBark(String bark) {
			this.bark = bark;
		}
		
	}
}
	public static void main(String[] args) {
		dog obj =new dog();
		obj.setBark("Yes");
		obj.setPet("Yes");
		System.out.println(obj.getBark());
		System.out.println(obj.getPet());

	}

}
