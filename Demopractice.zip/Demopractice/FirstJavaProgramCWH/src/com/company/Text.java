package com.company;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;

public class Text {
	public static void main(String[] args) throws COSVisitorException {
		try {
			PDDocument document=PDDocument.load(new File("c:\\CV_Tejal_Kothavade.pdf"));
			PDFTextStripper pdftextstripper=new PDFTextStripper();
			String text=pdftextstripper.getText(document);
			System.out.println(text);
			document.save("c:\\CV_Tejal_Kothavade.txt");
			document.close();
			
			
		}
		catch(IOException e) {
			e.printStackTrace();
			
			
		}
		
		
		
	}

}
