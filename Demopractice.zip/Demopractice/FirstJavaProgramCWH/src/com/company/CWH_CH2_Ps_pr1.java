package com.company;

public class CWH_CH2_Ps_pr1 {

	public static void main(String[] args) {
		//Question1
		float a=7/4.0f * 9/2.0f;
		System.out.println(a);

	}

}
