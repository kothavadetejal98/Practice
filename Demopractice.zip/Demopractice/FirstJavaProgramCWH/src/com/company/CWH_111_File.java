package com.company;

import java.io.File;
import java.io.IOException;

public class CWH_111_File {

	public static void main(String[] args) throws IOException {
		//create a file
		File obj=new File("cwh111.txt");
        obj.createNewFile();
	}
	//code to write to a file
     
}
