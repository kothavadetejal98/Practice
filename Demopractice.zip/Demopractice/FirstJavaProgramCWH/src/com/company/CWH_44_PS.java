package com.company;

public class CWH_44_PS {
	static  class Rectangle{
		 int length;
		 int breath;
		public Rectangle() {
			super();
			this.length = 4;
			this.breath = 6; 
			
		}
		public Rectangle(int length, int breath) {
			super();
			this.length = length;
			this.breath = breath;
		}
		public int getLength() {
			return length;
		}
		public void setLength(int length) {
			this.length = length;
		}
		public int getBreath() {
			return breath;
		}
		public void setBreath(int breath) {
			this.breath = breath;
		} 
		 
		 
	 }

	public static void main(String[] args) {
		Rectangle r= new Rectangle();
		System.out.println(r.getBreath());
		System.out.println(r.getLength());
	}

}
