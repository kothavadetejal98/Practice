package com.company;

public class CWH_49_dyanamic_method_dispatch {
	
	static class phone{
		
		public void greety() {
			System.out.println("Good Morning");
		}
		public void on(){
			System.out.println("Turning on phone");
		}
		
	}
	
	static class smartphone extends phone{
		public void swagat() {
			System.out.println("Welcome");
		}
		public void on(){
			System.out.println("Turning on smartphone");
		}
	}

	public static void main(String[] args) {
		
//		phone obj=new phone();
//		
//		smartphone obj1=new smartphone();
//		obj1.name();
		phone obj=new smartphone();
		obj.greety();
		obj.on();
		
		

	}

}
