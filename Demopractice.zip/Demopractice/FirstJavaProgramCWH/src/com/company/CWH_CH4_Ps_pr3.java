package com.company;

import java.util.Scanner;

public class CWH_CH4_Ps_pr3 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int income=sc.nextInt();
		if(income<2.5) {
			System.out.println("No tax");
		}
		
		else if(income>2.5 && income<5.0) {
			System.out.println("Tax will be 5%");
		}
		else if(income>5.0 && income<10.0) {
			System.out.println("Tax will be 20%");
		}
		else {
			System.out.println("Tax will be 30%");
	}

	}
}
