package com.company;

public class CWH_04_Literal {
	public static void main(String[] args) {
		byte age=34;
		char ch='a';
		float f1=5.6f;
		double d=0.99;
		int age1=89;
		boolean num=true;
		short sum=89;
		long num2=9000000l;
		
		System.out.println(age);
		System.out.println(ch);
		System.out.println(f1);
		System.out.println(d);
	}

}
