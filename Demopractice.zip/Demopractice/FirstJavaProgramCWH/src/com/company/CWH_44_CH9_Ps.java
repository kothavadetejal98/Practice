package com.company;



public class CWH_44_CH9_Ps {

	static class cylinder {
		int height;
		int radius;
		
		public cylinder(int myheight,int myradius) {
			height=myheight;
			radius=myradius;
			
		}
		
		

		public int getHeight() {
			return height;
		}

		public void setHeight(int height) {
			this.height = height;
		}

		public int getRadius() {
			return radius;
		}

		public void setRadius(int radius) {
			this.radius = radius;
		}
		
		public double surfacearea() {
			return 2*3.14*radius*radius+2*3.14*radius*height;
		}
		
		public double volume() {
			return 3.14*radius*radius*height;
		}

	}

	public static void main(String[] args) {
		//problem 1
		//problem 3
		cylinder obj = new cylinder(9, 12);
		obj.setHeight(12);
		obj.setRadius(9);
		System.out.println(obj.getHeight());
		System.out.println(obj.getRadius());
		
		//problem 2
		System.out.println(obj.surfacearea());
		System.out.println(obj.volume());
		
		
	}

}