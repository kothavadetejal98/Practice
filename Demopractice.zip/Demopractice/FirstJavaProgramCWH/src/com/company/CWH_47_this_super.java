package com.company;

import com.company.CWH_47_this_super.Ekclass.doclass;

public class CWH_47_this_super {
	static class Ekclass{
		int a;
		
		
		public int getA() {
			return a;
		}
		Ekclass(int a) {
			this.a=a;
		}
		public int one() {
			return 1;
		}
		
		static class doclass{
			doclass(int c){
				//super();
				System.out.println("I am a constructor");
			}
		}
	}

	public static void main(String[] args) {
		Ekclass obj=new Ekclass(5);
		doclass obj1=new doclass(5);
		System.out.println(obj.getA());
	}

}
