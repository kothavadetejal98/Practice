package com.company;

public class CWH_CH2_Operator {

	public static void main(String[] args) {
		int a=3;
		int b=3;
		int c=a%b;
		int sum=a+b;
		System.out.println(sum);
		System.out.println(c);
		System.out.println(45>98);
		System.out.println(2>1 || 1>2);
		System.out.println(12>9 && 2>1);
	}

}
