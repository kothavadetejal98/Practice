package com.company;

public class Evaluation {
	
	  int perimeter(int x,int y) {
		int z;
		z=2*(x+y);
		return z;
	}
	

	public static void main(String[] args) {
		Evaluation obj=new Evaluation();
		int a=3;
		int b=5;
		int c=obj.perimeter(a,b);
		System.out.println(c);

	}

}
