package com.company;

import com.company.CWH_46_Constructor_in_inheritance.Base.Derived;
import com.company.CWH_46_Constructor_in_inheritance.Base.Derived.Child;

public class CWH_46_Constructor_in_inheritance {
	
	static class Base{
		
		Base(){
			System.out.println("I am a constructor");
		}
		Base(int x){
			System.out.println("I am an overloaded constructor");
		}
		
		 
		static class Derived extends Base{
			
			Derived(){
				super(0);
				System.out.println("I am a derived class constructor");
			}
			Derived(int x,int y){
				super(x);
				System.out.println("I am an overloaded derived class constructor");
			}
			
			static class Child extends Derived{
				Child(){
					System.out.println("I am a child");
				}
				Child(int x,int y,int z){
					super(x,y);
					System.out.println("I am an overloaded child of derived class constructor");
				}
			}
			
			
		}
	}

	public static void main(String[] args) {
		//Base obj =new Base();
		Derived obj1=new Derived(14,9);
        Child obj2=new Child(14,9,8);
        
	}

}
