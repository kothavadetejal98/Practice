package com.company;

public class CWH_76_CH13_Ps {
	static class demo extends Thread{
		public void run() {
			//while(true) {
				System.out.println("Good Morning");
			}
			
		}
	//}
	static class demo1 extends Thread{
		public void run() {
			//while(true) {
				System.out.println("Welcome");
				try {
					Thread.sleep(200);
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			
		}
	//}

	public static void main(String[] args) {
		demo t1=new demo();
		demo1 t2=new demo1();
		demo1 t3=new demo1();
				
		t1.start();
		t2.start();
		//t3.start();
		t2.setPriority(8);
		//t3.setPriority(9);
		//System.out.println(t3.getPriority());
		System.out.println(t2.getPriority());
		System.out.println(t3.getState());
	}

}
