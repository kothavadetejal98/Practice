package com.company;

public class CWH_40_Acceessmodifier {
	
   static class Circle {
	 private  int radius;
	  private int area;
	   
	  

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}
	   
   }

	public static void main(String[] args) {
		Circle obj=new Circle();
		obj.setRadius(5);
		System.out.println(3.714*obj.radius*obj.radius);

	}

}
