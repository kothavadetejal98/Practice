package com.company;

import java.util.ArrayList;

public class CWH_104_EX7_Librarymanagementsystem {
	class Book{
		public String name,author,issued_to,issued_on;
	}
	class Library{
		public ArrayList<Book> books;
		public Library(ArrayList<Book> books) {
			this.books=books;
		}
		public void addBook(Book book) {
			System.out.println("The book has been added to the library");
			this.books.add(book);
		}
		public void issueBook(Book book) {
			System.out.println("The book has been issued from the library");
			this.books.remove(book);
		}

		public void returnBook(Book b) {
			System.out.println("The book has been returned");
			this.books.add(b);
		}
	}

	public static void main(String[] args) {
		ArrayList<Book> bk=new ArrayList<>();
	

	}

}
