package com.company;

public class CWH_33_VarArgs {
	
	static int sum(int x,int y) {
		return x+y;
	}

	public static void main(String[] args) {
		System.out.println("Welcome");
		
		System.out.println(sum(4,5));

	}

}

