package com.company;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

//class MyComparator implements Comparator<Integer> {
//
//	public int compare(Integer I1, Integer I2) {
//		return (I1<I2)?-1:(I1>I2)?1:0;
//	}
//
//}

public class Comparator1java8 {
	public static void main(String[] args) {
		ArrayList<Integer> l1 = new ArrayList<Integer>();
		ArrayList<String> s1=new ArrayList<String>();
		s1.add("Tejal");
		s1.add("John");
		l1.add(18);
		l1.add(10);
		l1.add(11);
		Comparator<String> comp=(S1,S2)->S1.compareTo(S2);
		Collections.sort(s1,comp);
		System.out.println(s1);
		Comparator<Integer> MyComparator=(I1,I2)->(I1<I2)?-1:(I1>I2)?1:0;
		Collections.sort(l1,  MyComparator);
		System.out.println(l1);
	}

}
