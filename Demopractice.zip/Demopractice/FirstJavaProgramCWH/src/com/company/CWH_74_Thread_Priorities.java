package com.company;

 class mythrr extends Thread{
	public mythrr(String name) {
		super(name);
	}
	public void run() {
		System.out.println("Thank you" + this.getName());
	}
	
}

public class CWH_74_Thread_Priorities {

	public static void main(String[] args) {
		mythrr t1=new mythrr("Joe1");
		mythrr t2=new mythrr("Joe2");
		mythrr t3=new mythrr("Joe3");
		mythrr t4=new mythrr("Joe4");
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t4.setPriority(Thread.MAX_PRIORITY);
	}

}
