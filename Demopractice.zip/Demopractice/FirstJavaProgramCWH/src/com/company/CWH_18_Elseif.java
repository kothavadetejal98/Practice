package com.company;

import java.util.Scanner;

public class CWH_18_Elseif {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	if(a>8) {
		System.out.println("Safe");
	}
	else if(a==8){
		System.out.println("Safe on boundary");
	}
	else {
		System.out.println("Not safe");
	}

	}

}
