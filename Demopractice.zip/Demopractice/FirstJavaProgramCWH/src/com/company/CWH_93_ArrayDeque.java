package com.company;

import java.util.ArrayDeque;

public class CWH_93_ArrayDeque {
public static void main(String[] args) {
	ArrayDeque<Integer> ad1=new ArrayDeque<>();
	ad1.add(78);
	ad1.add(98);
	ad1.addLast(9);
	ad1.addFirst(3);
	System.out.println(ad1.getFirst());
	System.out.println(ad1.getLast());
	
}
}
