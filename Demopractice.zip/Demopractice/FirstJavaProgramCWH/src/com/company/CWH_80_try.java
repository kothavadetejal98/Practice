package com.company;

public class CWH_80_try {

	public static void main(String[] args) {
		int a=6000;
		int b=0;
		try {
			double c=a/b;
			System.out.println("The result is" + c);
		}
		catch(Exception e) {
			System.out.println("We fail to divide");
			System.out.println(e);
		}
		
	}

}
