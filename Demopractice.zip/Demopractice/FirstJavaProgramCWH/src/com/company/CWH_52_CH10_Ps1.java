package com.company;

public class CWH_52_CH10_Ps1 {
	static class Rectangle{
		int length;
		int breath;
		public int getLength() {
			return length;
		}
		
		public int area() {
			return length*breath;
		}
		public void setLength(int length) {
			this.length = length;
		}
		public int getBreath() {
			return breath;
		}
		public void setBreath(int breath) {
			this.breath = breath;
		}
		
		
	}
	static class Cuboid extends Rectangle{
		int height;

		
		public int getHeight() {
			return height;
		}


		public void setHeight(int height) {
			this.height = height;
		}


		public int volume() {
			return length*breath*height;
		}
		
	}

	public static void main(String[] args) {
		Cuboid obj=new Cuboid();
		obj.setBreath(8);
		obj.setLength(9);
		obj.setHeight(10);
		System.out.println(obj.getBreath());
		System.out.println(obj.getLength());
		System.out.println(obj.getHeight());
		System.out.println(obj.area());
		System.out.println(obj.volume());

	}

}
