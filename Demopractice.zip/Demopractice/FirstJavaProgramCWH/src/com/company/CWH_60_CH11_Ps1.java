package com.company;

import com.company.CWH_60_CH11_Ps1.monkey.human;

public class CWH_60_CH11_Ps1 {
	interface animal{
		public void eat();
		public void sleep();
	}
	
	static class monkey{
		public void jump() {
			System.out.println("jump");
		}
		public void bite() {
			System.out.println("bite");
		}
		
		
		
	static class human extends monkey implements animal{

			@Override
			public void eat() {
				System.out.println("eat");
			}

			@Override
			public void sleep() {
				System.out.println("sleep");
				
			}
			
		}
	}

	public static void main(String[] args) {
		human obj=new human();
		obj.bite();
		
		monkey m1=new human();
		m1.jump();
		
        
	}

}
