package com.company;

public class CWH_39_CH8_PS {
	
	//problem 1

//	static class Employee {
//		int salary;
//		String name;
//
//		public int getSalary() {
//			return salary;
//		}
//
//		public String getName() {
//			return name;
//		}
//
//		public void setSalary(int n) {
//			salary = n;
//		}
//
//		public void setName(String n) {
//			name = n;
//		}
//
//	}
//
//	public static void main(String[] args) {
//		Employee obj = new Employee();
//		obj.setName("Harry");
//		obj.setSalary(1000);
//
//		System.out.println(obj.getName());
//		System.out.println(obj.getSalary());
//
//	}
	
	//problem 2
	
//	static class Phone{
//		public void ringing() {
//			System.out.println("phone is ringing");
//		}
//		public void vibrating() {
//			System.out.println("phone is vibrating");
//		}
//	}
//	public static void main(String[] args) {
//		Phone obj=new Phone();
//		obj.ringing();
//		obj.vibrating();
//		
//	}
	
	//problem 3
//	static class Square{
//		int length;
//		int breath;
//		int area;
//		int perimeter;
//		public void print() {
//			System.out.println(area);
//			System.out.println(perimeter);
//		}
//	}
//	
//	
//	public static void main(String[] args) {
//		Square obj=new Square();
//		obj.length=3;
//		obj.breath=3;
//		obj.area=obj.length*obj.breath;
//		obj.perimeter=2*(obj.length+obj.breath);
//		obj.print();
//	}
	
	
	

}
