package com.company;

import com.company.CWH_49_dyanamic_method_dispatch.phone;

public class CWH_108_Annotation {
	
	
	static class newphone extends phone{
		public void on(){
			System.out.println("phone on");
		}
		@Deprecated
		public int sum(int a,int b) {
			return a+b;
		}
	}

	public static void main(String[] args) {
		@SuppressWarnings("Deprecation")
		newphone obj=new newphone();
		obj.on();
		obj.sum(9, 7);
	}

}
