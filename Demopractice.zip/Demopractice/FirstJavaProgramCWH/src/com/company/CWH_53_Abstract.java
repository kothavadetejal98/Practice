package com.company;

public class CWH_53_Abstract {
	abstract  static class parent{
		public parent() {
			System.out.println("I am a constructor");
		}
		public void hello(){
			System.out.println("hello");
		}
		abstract public void greet();
	}
	
	static class child extends parent{
		@Override
		public void greet() {
			System.out.println("Good Morning");
		}
	}

	public static void main(String[] args) {
		child obj=new child();
	}

}
