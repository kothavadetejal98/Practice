package com.company;

import java.util.Scanner;

public class PercentageCalculator {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Mark of Hindi is");
		int Hindi=sc.nextInt();
		System.out.println("Mark of English is");
		int English=sc.nextInt();
		System.out.println("Mark of Marathi is");
		int Marathi=sc.nextInt();
		System.out.println("Mark of Math is");
		int Math=sc.nextInt();
		System.out.println("Mark of History is");
		int History=sc.nextInt();
		
		float percentage=((Hindi+English+Marathi+Math+History)/500.0f)*100;
		System.out.println("Percentage of the student is " + percentage);

	}

}
