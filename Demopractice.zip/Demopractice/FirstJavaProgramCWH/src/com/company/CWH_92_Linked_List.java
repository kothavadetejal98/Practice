package com.company;

import java.util.*;

public class CWH_92_Linked_List {

	public static void main(String[] args) {
		LinkedList<Integer> L1=new LinkedList<>();
		LinkedList<Integer> L2=new LinkedList<>();
		L1.add(6);
		L1.add(7);
		L1.add(8);
		L1.add(9);
		L1.add(10);
		L2.add(11);
		L2.add(12);
		L2.add(13);
		L1.addAll(0, L2);
		L1.addLast(19);
		L1.addFirst(98);
		L2.addFirst(97);
		
		
		
		System.out.println(L1.contains(7));
		for(int i=0;i<L1.size();i++) {
			System.out.println(L1.get(i));
			System.out.println(L1.indexOf(8));
		}
		

	}

}
