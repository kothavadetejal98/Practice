package com.company;

class mythr2 extends Thread{
	public mythr2(String name) {
		super(name);
	}
	public void run() {
		//while(true) {
			System.out.println("Thread Class");
		//}
		
	}
}
class mythr3 extends Thread{
	public mythr3(String name) {
		super(name);
	}
	public void run() {
		//while(true) {
			System.out.println("Thread Class is active");
		//}
		
	}
}

public class CWH_75_Thread_Method {

	public static void main(String[] args) {
		mythr2 obj=new mythr2("Smith");
		mythr2 obj1=new mythr2("Smith");
		mythr3 obj3=new mythr3("Smith");
        obj.start();
        
        
        try {
        	 obj.join();
        }
        catch(Exception e) {
        	System.out.println(e);
        }
       
        obj1.start();
        obj3.start();
	}

}
