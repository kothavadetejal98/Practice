package com.company;

public class CWH_CH6_PS {

	public static void main(String[] args) {
		//Question1
//		float sum=0;
//		float[] number= {10f,20f,60f,80f,90f};
//		for(int i=0;i<number.length;i++) {
//			System.out.println(number[i]);
//			sum=sum+number[i];
//			
//		}
//		System.out.println(sum);
		
		//Question 3
//		float[] marks= {10,20,30,40};
//		float avg=0;
//		for(int i=0;i<marks.length;i++) {
//		System.out.println(marks[i]);
//		System.out.println(marks.length);
//		avg=(avg+marks[i]);
//		
//	
//		}
//		//System.out.println(avg/marks.length);
//	}

		
//		Question 4;
//		int sum=0;
//		int[][] flats= new int[2][3];
//		flats[0][0]=101;
//		flats[0][1]=102;
//		flats[0][2]=103;
//		flats[1][0]=201;
//		flats[1][1]=202;
//		flats[1][2]=203;
//		
//		for(int i=0;i<flats.length;i++) {
//			for(int j=0;j<flats[i].length;j++) {
//				System.out.print(flats[i][j]);
//				System.out.print(" ");
//				sum=sum+flats[i][j];
//				
//			}
//			System.out.println(sum);
//		}
		
//		//Question 5
//		int[] num= {10,20,30,40,50};
//		for(int i=num.length-1;i>=0;i--) {
//			System.out.println(num[i]);
//		}
		
		
		//Question 6-Max element in array
		int[] num= {20,30,50,87};
		int max=0;
		for(int element:num) {
			if(element>max) {
				max=element;
			}
			System.out.println("The value of max element is " + max);
		}
		
		//Question 7-min element in array
		
		int[] num1= {20,30,50,87};
		int min=30;
		for(int element:num1) {
			if(element<min) {
				min=element;
			}
			System.out.println("The value of min element is " + min);
			
		}
		
	}
	
}
