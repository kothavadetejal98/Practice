package com.company;

import com.company.CWH_112_PS.MyDeprecated.Myint;

public class CWH_112_PS {
	
	static class MyDeprecated{
		@Deprecated
		void meth1(){
			System.out.println("I am a meth1");
		}
		interface Myint{
			void display();
		}
	}

	public static void main(String[] args) {
		MyDeprecated d=new MyDeprecated();
        d.meth1();
        
        Myint j=new Myint() {

			@Override
			public void display() {
				System.out.println("I am display");
				
			}
        	
        };
	}

}
