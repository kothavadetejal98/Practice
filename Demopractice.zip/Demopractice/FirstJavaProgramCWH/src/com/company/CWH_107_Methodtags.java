package com.company;

public class CWH_107_Methodtags {

	public static void main(String[] args) {
		System.out.println("I am a main method");

	}
	/**
	 * 
	 * @param a this is first number
	 * @param b this is second number
	 * @return sum of this number
	 * @throws exception a is 0
	 */
	public int add(int a,int b)throws Exception{
		if(a==0) {
			throw new Exception();
		}
		return a+b;
	}

}
