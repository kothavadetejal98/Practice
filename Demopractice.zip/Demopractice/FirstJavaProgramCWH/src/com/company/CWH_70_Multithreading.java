package com.company;

public class CWH_70_Multithreading {
	static class thread{
		
		public void start() {
			System.out.println("Thread are started");
		}
		public void run() {
			System.out.println("run");
		}
	}
	static class mythread extends thread{
		@Override
		public void run() {
			
				System.out.println("my thread is running");
				System.out.println("I am happy");
			
			
		}
		
	}
	static class mythread1 extends thread{
		@Override
		public void run() {
			
				System.out.println("my thread1 is running");
				System.out.println("I am sad");
			
			
		}
		
	}

	public static void main(String[] args) {
		mythread obj=new mythread();
		mythread1 obj1=new mythread1();
		obj.start();
		obj1.start();
		obj.run();
		obj1.run();

	}

}
