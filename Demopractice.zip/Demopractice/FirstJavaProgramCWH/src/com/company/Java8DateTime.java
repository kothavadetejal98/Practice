package com.company;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.Period;

public class Java8DateTime {
	public static void main(String[] args) {
		LocalDate date=LocalDate.now();
		System.out.println(date);
		
		LocalTime time=LocalTime.now();
		System.out.println(time);
		
		int nano=time.getNano();
		System.out.println(nano);
		
		int dd=date.getDayOfMonth();
		System.out.println(dd);
		
		int mm=date.getMonthValue();
		System.out.println(mm);
		
		int yyyy=date.getYear();
		System.out.println(yyyy);
		
		System.out.printf("%d-%d-%d",dd,mm,yyyy);
		
		LocalDateTime dt=LocalDateTime.now();
		System.out.println(dt);
		
		int dd1=dt.getDayOfMonth();
		int mm1=dt.getMonthValue();
		int yyyy1=dt.getYear();
		System.out.printf("%d-%d-%d",dd1,mm1,yyyy1);
		
		
		LocalDateTime dt1=LocalDateTime.of(1995, Month.MAY, 28, 12, 45);
		System.out.println(dt1);
		System.out.println("After six month" + dt1.plusMonths(5));
		System.out.println("Before six month" + dt1.minusMonths(6));
		
		LocalDate birtday=LocalDate.of(1997, Month.DECEMBER, 19);
		LocalDate today=LocalDate.now();
		Period p=Period.between(birtday, today);
		System.out.println(p);
		
		
		
	}

}
