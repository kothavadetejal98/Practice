package com.company;

public class CWH_18_Switchcase {

	public static void main(String[] args) {
		int age = 45;
		switch (age) {
		case 18:
			System.out.println("Adult");
			break;
		case 24:
			System.out.println("Ready for job");
			break;

		default:
			System.out.println("Enjoy your life");

		}

	}

}
