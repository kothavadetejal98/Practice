package com.company;

import java.util.ArrayList;
import java.util.function.Predicate;

public class Employee {
	public static void main(String[] args) {
		int[] s= {0,5,10,15,20};
		Predicate<Integer> p=s1->s1%2==0;
		for(int s1:s) {
			if(p.test(s1)) {
				System.out.println(s1);
			}
		}
	}
	
	}
	
	
	
	

