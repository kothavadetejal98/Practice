package com.company;

public class CWH_35_CH7_Ps {
	
	//problem 1:multiplication table of n
//	static void  table(int n) {
//		for(int i=1;i<=10;i++) {
//			System.out.println(n*i);
//		}
//	}
//
//	public static void main(String[] args) {
//		table(7);
//	}
	
	//problem 2:print pattern
//	static void pattern(int n) {
//		for(int i=0;i<=n;i++) {
//			for(int j=0;j<=i;j++) {
//				System.out.print("*");
//			}
//			System.out.println("\n");
//		}
//	}
//	public static void main(String[] args) {
//	 pattern(3);
//	}
	
	
	//problem 3:sum of first n natural number
//	static void sum(int n) {
//		int sum=0;
//		for(int i=0;i<=n;i++) {
//			
//			System.out.println(i);
//			sum=sum+i;
//		}
//		System.out.println(sum);
//	}
//	public static void main(String[] args) {
//		sum(10);
//	}
	
	//problem 4:print the pattern
//	static void pattern(int n) {
//		for(int i=n;i>=0;i--) {
//			for(int j=0;j<=i;j++) {
//				System.out.print("*");
//			}
//			System.out.println("\n");
//		}
//	}
//	public static void main(String[] args) {
//	 pattern(3);
//	}
	
	//problem 5:fibonaci series-0 1 1 2 3 5 8 13 21 34
	
	
	
	

	}
	
