package com.company;
interface x{
	void add();
	
}

class detail implements x {
	 
    
    @Override 
    public void add()
    {
       
        System.out.print("add");
    }
}
public class CWH_109_lambda {

	public static void main(String[] args)
    {
        
//       detail obj = new detail();
// 
//       
//        obj.add();
       //Anonymous class 
//        x obj1=new x() {
//        	@Override 
//            public void add()
//            {
//               
//                System.out.print("add");
//            }
//        };
		
		//Lambda Expression
		x obj=new detail();
		obj.add();
    }
}

		

