package com.company;

public class CWH_CH3_ps {

	public static void main(String[] args) {
		//Question 1
		String name="SWARA";
		System.out.println(name.toLowerCase());
		
		//Question 2
		String sentence="I am a girl";
		System.out.println(sentence.replace( " ", "_"));
		
		//Question 3
		String name1="Ruhi";
		System.out.println("Dear " + name1 + " Thanks a lot");
		System.out.println(name1.replace("Ruhi","Joe" ));
		
		//Question 4
		String name2=" I   am  a  good     girls";
		System.out.println(name2.indexOf("   "));
		
		//Question 5
		String letter="This is a good java course.\n\tThanks!";
		System.out.println(letter);
	}

}
