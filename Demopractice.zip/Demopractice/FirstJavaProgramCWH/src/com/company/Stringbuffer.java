package com.company;

public class Stringbuffer {
	public static void main(String[] args) {
		StringBuffer a=new StringBuffer("Tejal");
		a.reverse();
		System.out.println(a);
	}
}
