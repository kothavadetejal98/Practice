package com.company;

public class CWH_31_Method {
	
	 int logic(int x,int y) {
		int z;
		if(x>y) {
			z=x+y;
		}
		else {
			z=(x+y)*5;
		}
		return z;
	}

	public static void main(String[] args) {
		CWH_31_Method obj=new CWH_31_Method();
		int a=9;
		int b=2;
		int c;
		c=obj.logic(a,b);
		System.out.println(c);

	}

}
