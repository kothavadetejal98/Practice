package com.company;

interface Interf1 {
	public int squareIt(int n);

	
		public static void main(String[] args) 
		{
			Interf1 i=n->n*n;
			System.out.println(i.squareIt(4));
		
		
	}
}
	


