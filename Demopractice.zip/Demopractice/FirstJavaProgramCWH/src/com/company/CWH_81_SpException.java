package com.company;

import java.util.Scanner;

public class CWH_81_SpException {

	public static void main(String[] args) {
		int[] marks=new int[5];
        marks[0]=9;
        marks[1]=10;
        marks[2]=8;
        marks[3]=7;
        marks[4]=6;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the array index");
      int ind=  sc.nextInt();
      System.out.println("enter the number you want to divide");
      int number=sc.nextInt();
      
      try {
    	  System.out.println(marks[ind]);
    	  System.out.println(marks[ind]/number);
      }
      catch(Exception e){
    	  System.out.println("some exception are occure");
    	  System.out.println(e);
      }
	}

}
