package com.company;

import java.util.Scanner;

public class Inter {
	String s="chinchwad";
	
	
	public static void main(String[] args) {
		Inter obj=new Inter();
		System.out.println(obj.s.substring(3));
	}

}
