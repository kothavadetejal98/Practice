package com.company;

public class CWH_CH4_Ps_pr5 {

	public static void main(String[] args) {
		int year=1998;
		if((year%400==0) || ((year%4==0) && (year%100!=0)) ){
			System.out.println("This year is leap year");
		}
		else {
			System.out.println("This year is not leap year");
		}

	}

}
