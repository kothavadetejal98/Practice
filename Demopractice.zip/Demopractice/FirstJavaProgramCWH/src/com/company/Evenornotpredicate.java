package com.company;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Evenornotpredicate {
	public static void main(String[] args) {
		Predicate<Integer> s=i->i%2==0;
		System.out.println(s.test(9));
		
	Integer[]	l1 = {1,2,3,4,5,6,7};
	List<Integer> number=Arrays.asList(l1);
	List<Integer> number1=number.stream().filter(i->i%2==0).collect(Collectors.toList());
	System.out.println(number1);
	
	
	
	
		
		
		
	}

}
