package com.company;

public class CWH_25_CH5__PS1 {

	public static void main(String[] args) {
		// pattern problem
//		int n=4;
//		for(int i=0;i<4;i++) {
//			for(int j=0;j<i;j++) {
//				System.out.print("*");
//			}
//			System.out.println();
//		}
//		
		// sum of first even natural number
		int n1 = 3;
		

		for (int i1 = 0; i1 <= 3; i1++) {
			System.out.println(2*i1);

		}
		

	}
}