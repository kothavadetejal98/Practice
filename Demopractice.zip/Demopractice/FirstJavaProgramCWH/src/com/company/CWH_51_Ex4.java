package com.company;

public class CWH_51_Ex4 {
	 static class library{
		 
		 int[] availablebook= {};
		 int[] issuebook= {};
		 
		 public void addbook() {
			 System.out.println("Book is added");
		 }
		 
		 public void issuebook() {
			 System.out.println("Book is issued");
		 }
		 public void returnbook() {
			 System.out.println("Book is return");
		 }
		 
		 public void showavailablebook() {
			 System.out.println("Available books");
		 }
		 
	 }

	public static void main(String[] args) {
		library obj=new library();
	}
	
	

}
