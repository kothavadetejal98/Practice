package com.company;

import java.util.Scanner;

public class CWH_CH2_Ps_pr3 {

	public static void main(String[] args) {
		int a=10;
		System.out.println("Taking user input");
		Scanner sc=new Scanner(System.in);
		int b=sc.nextInt();
		boolean c=(a>b);
		System.out.println(c);
		

	}

}
