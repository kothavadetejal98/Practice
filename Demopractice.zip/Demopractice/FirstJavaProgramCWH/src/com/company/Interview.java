package com.company;

public class Interview {
   static class add  {
	   int a;
	   int b;
	   int c;
	   
   }
   public static void main(String[] args) {
	add obj=new add();
	obj.a=9;
	obj.b=8;
	obj.c=7;
	System.out.println(obj.a+obj.b+obj.c);
}

}
