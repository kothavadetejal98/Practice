package com.company;

public class CWH_68_Ex5 {
	static class shape{
		int length=9;
		int breath=8;
		int radius=14;
		int height=6;
		
	}
	

	static class Rectangle extends shape{
		
		
		public int surfaceareaofrec() {
			return length*breath;
		}

		
	}
	static class Square extends shape{
		public int surfaceareaofsquare() {
			return length*breath;
		}
		
	}
	static class Circle extends shape{
		public double surfaceareaofcircle() {
			return Math.PI*radius*radius;
		}
		
	}
	static class Cylinder extends shape{
		public double surfaceareaofcylinder() {
			return (2*Math.PI*radius*radius)+(2*Math.PI*radius*height);
		}
	}
	static class Sphere extends shape{
		public double surfaceareaofsphere() {
			return 4*Math.PI*radius*radius;
		}
		public double volumeofsphere() {
			return 4/3*Math.PI*radius*radius*radius;
		}
	}
	
	

	public static void main(String[] args) {
		shape demo=new shape();
		Rectangle obj=new Rectangle();
		Square obj1=new Square();
		Circle obj2=new Circle();
		Cylinder obj3=new Cylinder();
		Sphere obj4=new Sphere();
		
		
		System.out.println(obj.surfaceareaofrec());
		System.out.println(obj1.surfaceareaofsquare());
		System.out.println(obj2.surfaceareaofcircle());
		System.out.println(obj3.surfaceareaofcylinder());
		System.out.println(obj4.surfaceareaofsphere());
		
		
	}

}
