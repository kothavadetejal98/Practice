package com.company;

public class CWH_17_Logical {

	public static void main(String[] args) {
		boolean a=true;
		boolean b=false;
		if(a && b) {
			System.out.println(true);
		}
		else {
			System.out.println(false);
		}
		
		if(a||b) {
			System.out.println(true);
			
			
		}
		else {
			System.out.println(false);
		}
			
		

	}

}
