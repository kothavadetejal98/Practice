package com.company;

public class CWH_16_Conditional {

	public static void main(String[] args) {
		int age=18;
		boolean condn=age>=18;
		if(condn) {
			System.out.println("Allow for drive");
		}
		else {
			System.out.println("Driving not allowed");
		}

	}

}
