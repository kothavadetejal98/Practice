package com.company;

public class CWH_57_Defaultmethod {
	interface camera{
		void takesnap();
		void recordvideo();
	}
	interface wifi{
		String[] getnetwork();
		void connecttonetwork(String network);
	}
	
	class mycellphone{
		void callnumber(int phonenumber){
			System.out.println("calling" + phonenumber);
		}
		 void pickcall() {
			 System.out.println("connecting");
		 }
		
		
		
	}
	
	class smartphone extends mycellphone implements camera,wifi{

		@Override
		public String[] getnetwork() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void connecttonetwork(String network) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void takesnap() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void recordvideo() {
			// TODO Auto-generated method stub
			
		}
		
				
	}

	public static void main(String[] args) {
		

	}

}
