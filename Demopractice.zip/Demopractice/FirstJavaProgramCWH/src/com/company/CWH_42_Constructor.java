package com.company;

public class CWH_42_Constructor {
	static class Employee {
		private int id;
		private String name;
		private int salary;

		public Employee() {
			id = 45;
			name = "harry";
			salary = 10000;
		}

		public Employee(String myname, int myid, int mysalary) {
			id = myid;
			name = myname;
			salary = mysalary;

		}

		public int getSalary() {
			return salary;
		}

		public void setSalary(int salary) {
			this.salary = salary;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

	}

	public static void main(String[] args) {
		Employee obj = new Employee("Joe", 7, 10000);
//		obj.setName("Code with harry");
//		obj.setId(1);
		System.out.println(obj.getId());
		System.out.println(obj.getName());
		System.out.println(obj.getSalary());

	}

}
