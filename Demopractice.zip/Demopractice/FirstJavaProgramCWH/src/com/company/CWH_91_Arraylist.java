package com.company;
import java.util.*;
public class CWH_91_Arraylist {

	public static void main(String[] args) {
//		ArrayList<Integer> L1=new ArrayList<>();
//		ArrayList<Integer> L2=new ArrayList<>();
//		L1.add(6);
//		L1.add(7);
//		L1.add(8);
//		L1.add(9);
//		L1.add(10);
//		L2.add(11);
//		L2.add(12);
//		L2.add(13);
//		L1.addAll(0, L2);
//		
//		
//		System.out.println(L1.contains(7));
//		for(int i=0;i<L1.size();i++) {
//			System.out.println(L1.get(i));
//			System.out.println(L1.indexOf(8));
		List<Integer> numList=Arrays.asList(2,4,6,8,10);
		boolean result=numList.stream().noneMatch(temp-> temp*5%2==1);
		System.out.println(result);
		
		}
  	}


