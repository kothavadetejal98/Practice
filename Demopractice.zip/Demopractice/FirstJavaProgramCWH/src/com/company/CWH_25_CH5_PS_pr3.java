package com.company;

public class CWH_25_CH5_PS_pr3 {

	public static void main(String[] args) {
		//question 3
//		int n=10;
//		
//		for(int i=1;i<=10;i++) {
//			
//			System.out.println(2*i);
//		}
//		
		//question 4
//		int n=10;
//		for(int i=10;i>=1;i--) {
//			System.out.println(10*i);
//		}
		
		
		//question9
		int n=8;
		 int sum=0;
		for(int i=1;i<=10;i++) {
			System.out.println(i*n);
			sum=sum+(n*i);
			
		}
		System.out.println(sum);
		
	}

}
