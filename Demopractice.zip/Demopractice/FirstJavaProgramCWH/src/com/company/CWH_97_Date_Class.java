package com.company;

import java.util.Date;

public class CWH_97_Date_Class {

	public static void main(String[] args) {
		System.out.println(Long.MAX_VALUE);
		System.out.println(System.currentTimeMillis());
		Date d=new Date();
		System.out.println(d);
		System.out.println(d.getYear());
	}

}
