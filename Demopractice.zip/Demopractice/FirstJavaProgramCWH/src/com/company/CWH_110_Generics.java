package com.company;

import java.util.ArrayList;

public class CWH_110_Generics {

	public static void main(String[] args) {
		ArrayList al=new ArrayList();
		al.add("str1");
        al.add(54);
        al.add(63);
        int a=(int) al.get(2);
        System.out.println(a);
	}

}
