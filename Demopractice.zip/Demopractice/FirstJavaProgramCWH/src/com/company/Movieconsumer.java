package com.company;

import java.util.function.Consumer;

public class Movieconsumer {
	String name;

	public Movieconsumer(String name) {
		super();
		this.name = name;
	}
	public static void main(String[] args) {
		Consumer<Movieconsumer> m=s-> System.out.println(s.name + "movie is release");
		Consumer<Movieconsumer> m1=s-> System.out.println(s.name + "movie is flop");
		Movieconsumer s=new Movieconsumer("Spiderman");
		m1.accept(s);
		
		
	}
	

}
