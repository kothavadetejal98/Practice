package com.company;

public class CWH_82_Nestedtrycatch {

	public static void main(String[] args) {
		int[] marks=new int[5];
		marks[0]=1;
		marks[1]=2;
		marks[2]=3;
		marks[3]=4;
		marks[4]=5;
		try {
			System.out.println(marks[9]);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Array index out of limit");
			System.out.println(e);
		}
		
	}

}
