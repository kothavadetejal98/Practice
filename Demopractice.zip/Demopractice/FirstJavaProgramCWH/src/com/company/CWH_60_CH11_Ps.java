package com.company;

public class CWH_60_CH11_Ps {
	abstract static class pen{
		abstract void write(); 
		abstract void refill(); 
	}
	
	static class fountainpain extends pen{
		void write(){
			System.out.println("Write");
		}
		void refill() {
			System.out.println("Refill");
		}
		void changenib() {
			System.out.println("Changenib");
		}
	}

	public static void main(String[] args) {
		fountainpain obj=new fountainpain();
		obj.changenib();
		obj.write();
		obj.refill();
		
		
	}

}
