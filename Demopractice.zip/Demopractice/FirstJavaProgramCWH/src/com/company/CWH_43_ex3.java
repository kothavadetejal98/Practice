package com.company;

public class CWH_43_ex3 {
	
	static class game{
		int noofguesses;

		public int getNoofguesses() {
			return noofguesses;
		}

		public void setNoofguesses(int noofguesses) {
			this.noofguesses = noofguesses;
		}
		
		
	}
	
	public int game() {
		return 0;
		
	}
	
	public int takeuserinput() {
		return 0;
		
	}
	
	public boolean iscorrectnumber() {
		return false;
		
		
	}

	public static void main(String[] args) {
		

	}

}
