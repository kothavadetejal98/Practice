package com.company;

import java.util.ArrayList;
import java.util.function.Predicate;

public class Java8toArray {
	public static void main(String[] args) {
		ArrayList<Integer> l=new ArrayList<>();
		l.add(8);
		l.add(2);
		l.add(18);
		l.add(1);
		Integer[] i=l.stream().toArray(Integer[]::new);
		for(Integer i1:i) {
			System.out.println(i1);
			
			
			
 		}
		
		
	}
	
	
	
 
}
