package com.company;

public interface Lambda2java8{
	
	 public int square(int x);
	
	

	public static void main(String[] args) {
     Lambda2java8 i=x->x*x;
     System.out.println(i.square(4));


	}

}
