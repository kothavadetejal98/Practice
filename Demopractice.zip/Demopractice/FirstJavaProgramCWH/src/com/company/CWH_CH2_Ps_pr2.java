package com.company;

public class CWH_CH2_Ps_pr2 {

	public static void main(String[] args) {
		char grade='B';
		grade=(char) (grade+8);
		System.out.println(grade);
		grade=(char) (grade-8);
		System.out.println(grade);

	
	}

}
