package com.company;

public class CWH_32_Method_Overloading {
	static void foo() {
		System.out.println("Good Morning");
	}
	
	static void foo(int a) {
		System.out.println("Good Morning" + a );
	}
	
//	static void num(int x) {
//		x=67;
//	}
//	
//	static void num1(int[] num1) {
//		num1[0]=97;
//	}

	public static void main(String[] args) {
		
		//case1-changing the integer
//		int x=46;
//		num(x);
//		System.out.println(x);
		
		
		//case2-changing the array
//		int[] arr= {10,20,30,40};
//				num1(arr);
//		System.out.println(arr[0]);
		
		
		//Method Overloading
		int a;
		foo();
		
		foo(3000);

	}

}
