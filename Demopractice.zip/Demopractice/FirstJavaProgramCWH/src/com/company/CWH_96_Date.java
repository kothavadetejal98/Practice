package com.company;

import java.time.LocalDateTime;

public class CWH_96_Date {

	public static void main(String[] args) {
		System.out.println(System.currentTimeMillis());
		System.out.println(System.currentTimeMillis()/360/1000);
		LocalDateTime dt=LocalDateTime.of(1998, 05, 28, 05, 28);
		System.out.println(dt.plusMonths(6));
				
		System.out.println();
		
		

	}

}
