package com.company;

public class CWH_66_Accessmodifier {
	static class c1{
		public int x=5;
		protected int y=45;
		int z=9;
		private int a=78;
		
		public void meth1() {
			System.out.println(x);
			System.out.println(y);
			System.out.println(z);
			System.out.println(a);
		}
	}

	public static void main(String[] args) {
		c1 obj=new c1();
		obj.meth1();
		
	}

}
