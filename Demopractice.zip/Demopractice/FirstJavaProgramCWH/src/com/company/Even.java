package com.company;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Even {
	public static void main(String[] args) {
	
	
//	int number=l2.stream() .filter(num -> num % 2 == 0) .mapToInt(Integer::intValue) .sum();
//	System.out.println(number);
//		
//		int sum=IntStream.of(1,2,3,4,5,6,7,8,9,10).filter(n->n%2==0).sum();
//		System.out.println(sum);
//	int sum=IntStream.of(1,2,3,4).sum();
//	System.out.println(sum);
	List<Integer> l2=Arrays.asList(1,2,3,4,5,6,7,8,9,10);
	int sum=l2.stream().mapToInt(Integer::intValue) .sum();
	System.out.println(sum);
		
	}

}
