package com.company;

class mythr extends Thread{
	public mythr(String name) {
		super(name);
	}
	public void run(){
		//while(true) {
			System.out.println("I am a thread");
		//}
		
	}
}


public class CWH_73_ThreadConstructor {

	public static void main(String[] args) {
		mythr obj=new mythr("Joe");
		obj.start();
		System.out.println(obj.getId());

	}

}
