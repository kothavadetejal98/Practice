package com.company;

public class CWH_45_Inheritance {
	
	static class base{
		int x;
		int y;
		public int getX() {
			return x;
		}
		public void setX(int x) {
			this.x = x;
		}
		public int getY() {
			return y;
		}
		public void setY(int y) {
			this.y = y;
		}
		
		
	}
	
	static class derived extends base{
		int z;

		public int getZ() {
			return z;
		}

		public void setZ(int z) {
			this.z = z;
		}

		
		
		
	}

	public static void main(String[] args) {
		derived b=new derived();
		b.setX(6);
		b.setY(8);
		b.setZ(4);
		System.out.println(b.getX());
		System.out.println(b.getY());
		System.out.println(b.getZ());
	}

}
