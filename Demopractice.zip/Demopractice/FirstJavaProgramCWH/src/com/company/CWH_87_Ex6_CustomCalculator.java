package com.company;


public class CWH_87_Ex6_CustomCalculator {
	static class Invalidinputexception extends Exception
	{
	@Override
	public String toString() {
		
		return "Cannot add 8 & 9";
	}
	@Override
		public String getMessage() {
		
			return " I am getMessage()";
		}
	}
	static class Cannotdividebyzero extends Exception
	{
	@Override
	public String toString() {
		
		return "Cannot divide by 0";
	}
	@Override
		public String getMessage() {
		
			return " I am getMessage()";
		}
	}
	static class Inputisgreater extends Exception
	{
	@Override
	public String toString() {
		
		return "Inputisgreater";
	}
	@Override
		public String getMessage() {
		
			return " I am getMessage()";
		}
	}
	
	
	static class calculator {
		double add(double a,double b) throws Invalidinputexception, Inputisgreater {
			if(a>10000 || b>10000) {
				throw new Inputisgreater();
			}
			if(a==8 || b==9) {
				throw new Invalidinputexception(); 
			}
			
			return a+b;
		}
		double subtract(double a,double b) throws Inputisgreater {
			if(a>10000 || b>10000) {
				throw new Inputisgreater();
			}
			return a-b;
		}
		double multiply(double a,double b) throws Inputisgreater {
			if(a>10000 || b>10000) {
				throw new Inputisgreater();
			}
			return a*b;
		}
		
		double divide(double a,double b) throws Cannotdividebyzero, Inputisgreater {
			if(a>10000 || b>10000) {
				throw new Inputisgreater();
			}
			if (b==0) {
				 throw new Cannotdividebyzero(); 
			}
			return a/b;
		}
	}
	public static void main(String[] args) throws Invalidinputexception, Cannotdividebyzero, Inputisgreater {
		calculator c=new calculator();
		//c.add(8, 9);
	//	c.divide(6, 0);
		c.divide(10, 10001);
		
	}

}
