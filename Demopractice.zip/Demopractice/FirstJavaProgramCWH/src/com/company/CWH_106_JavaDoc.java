package com.company;

//@author Harry
//@version 0.1
//@see Google docs
public class CWH_106_JavaDoc {
	public void add(int a,int b) {
		System.out.println("The sum is" + a+b);
	}

	public static void main(String[] args) {
		System.out.println("I am a main method");

	}

}
