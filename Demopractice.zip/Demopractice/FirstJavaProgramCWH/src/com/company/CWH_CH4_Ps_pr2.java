package com.company;

import java.util.Scanner;

public class CWH_CH4_Ps_pr2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("value of a");
		int a=sc.nextInt();
		System.out.println("value of b");
		int b=sc.nextInt();
		System.out.println("value of c");
		int c=sc.nextInt();
		
		double percentage=(a+b+c)/3;
		System.out.println("The percentage of the student is" +  percentage);
		if(percentage>40 && a>=33 && b>=33 && c>=33) {
			System.out.println("Pass");
		}
		else {
			System.out.println("fail");
		}

	}

}
