package com.company;

public class CWH_48_MethodOverriding {
	
	static class base{
		int x;
		 public int harry(){
			 return 4;
		 }
		 
		 public void meth1(){
			 System.out.println("I am meth1");
		 }
	}
	
	static class derived extends base{
		public void meth12() {
			System.out.println("I am meth2");
		}
		@Override
		public void meth1(){
			 System.out.println("I am meth18");
		 }
	}

	public static void main(String[] args) {
		base obj=new base();
		obj.meth1();
		derived obj1=new derived();
        obj1.meth12();
	}

}
