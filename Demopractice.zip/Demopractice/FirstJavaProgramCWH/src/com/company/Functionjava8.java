package com.company;

import java.util.function.BiFunction;
import java.util.function.Function;

public class Functionjava8 {
	public static void main(String[] args) {
		Function<Integer,Integer> l=i->i*i;
		System.out.println(l.apply(7));
		Function<String,Integer> p=s->s.length();
		System.out.println(p.apply("Tejal"));
		
		BiFunction<Integer,Integer,Integer> s=(i,j)->(i*j);
		System.out.println(s.apply(3, 4));
	}

}
