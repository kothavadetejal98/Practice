package com.company;

import java.util.Scanner;

public class CWH_86_Ps {
	//problem 1
   // Syntax error  int a=7
	//logical error int age=78;
	//int bornyear=2000-78;
	//exception System.out.println(6/9);
	
	//problem 2
	
	
	public static void main(String[] args) {
		try {
			int a=5/0;
		}
		catch(IllegalArgumentException e) {
			System.out.println("HAHAAA");
		}
		catch(ArithmeticException e1) {
			System.out.println("hehe");
		
	}
	}
	
	
	
	
}

	
	






