package com.company;

public class CWH_52_CH10_Ps {
	static class circle{
		int radius;
		
		public double area() {
			return Math.PI*this.radius*this.radius;
		}

		public int getRadius() {
			return radius;
		}

		public void setRadius(int radius) {
			this.radius = radius;
		}
		
	}
	
	static class cylinder extends circle{
		int height;
		
		public double volume() {
			return Math.PI*this.radius*this.radius*this.height;
		}

		public int getHeight() {
			return height;
		}

		public void setHeight(int height) {
			this.height = height;
		}
	    
	}

	public static void main(String[] args) {
		cylinder obj =new cylinder();
		obj.setHeight(12);
		obj.setRadius(4);
		System.out.println(obj.getHeight());
		System.out.println(obj.getRadius());
		System.out.println(obj.volume());
		System.out.println(obj.area());

	}

}
