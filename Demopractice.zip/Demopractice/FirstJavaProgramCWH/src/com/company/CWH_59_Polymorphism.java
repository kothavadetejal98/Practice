package com.company;

import com.company.CWH_58_Inheritance_in_interface.sampleinterface;

public class CWH_59_Polymorphism {
	static class sampleinterface{
		void meth1() {
			System.out.println("meth1");
		};
		void meth2() {
			System.out.println("meth2");
		};
	}
	static class childsampleinterface extends sampleinterface{
		
		void meth3() {
			System.out.println("meth3");
		};
		void meth4() {
			System.out.println("meth4");
		};
		
	}

	public static void main(String[] args) {
		sampleinterface obj=new childsampleinterface();
		obj.meth1();
		obj.meth2();
	}

}
