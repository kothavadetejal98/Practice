package com.company;

import java.util.Scanner;

public class CWH_CH1_Ps {

	public static void main(String[] args) {
		//Question1-sum of three number
//		int a=98;
//		int b=90;
//		int c=76;
//		int sum=a+b+c;
//		System.out.println(sum);
//		
//		//Question2-cgpa of three subject
//		float sub1=89;
//		float sub2=76;
//		float sub3=67;
//		float cgpa=(sub1+sub2+sub3)/(3*10);
//		System.out.println(cgpa);
//		
//		//Question3-take user input and print Hello have a nice day
//		
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Taking user input");
//		
//		String str=sc.nextLine();
//		System.out.println(str);
//		
//		//Question4-convert- km to miles
//		Scanner convert=new Scanner(System.in);
//		System.out.println("Number in km");
//		float number=convert.nextFloat();
//		float miles= (float) (number*0.6213);
//		System.out.println(miles);
		
		//Question5-number is integer
		System.out.println("Enter the number");
		Scanner number1=new Scanner(System.in);
		
		System.out.println(number1.hasNextInt());
		
		
		
	}

}
