package com.company;

import java.util.function.Predicate;

public class Predicate1java8 {
	public static void main(String[] args) {
		Predicate<Integer> l=i->i%2==0;
		System.out.println(l.test(13));
		System.out.println(l.test(10));
		Predicate<String> s1=s->s.length()>=5;
		System.out.println(s1.test("Joe"));
		System.out.println(s1.test("Sarthak"));
		
	}

}

