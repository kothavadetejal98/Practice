package com.company;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Stream1 {

	public static void main(String[] args) {
		ArrayList<String> l1=new ArrayList<>();
		l1.add("Joe");
		l1.add("Smith");
		l1.add("John");
		System.out.println(l1);
		List<String> l2=l1.stream().filter(s->s.length()==3).collect(Collectors.toList());
		List<String> l3=l1.stream().map(s->s.toUpperCase()).collect(Collectors.toList());
		long count=l1.stream().filter(s->s.length()>=4).count();
		System.out.println(l2);
		System.out.println(l3);
		System.out.println(count);
		
		

	}

}
