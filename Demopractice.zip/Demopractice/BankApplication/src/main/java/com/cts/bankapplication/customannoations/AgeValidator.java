/**
 * 
 */
package com.cts.bankapplication.customannoations;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.time.LocalDate;

import javax.validation.Constraint;
import javax.validation.Payload;

@Documented
@Retention(RUNTIME)
@Target({ElementType.PARAMETER, FIELD})
@Constraint(validatedBy = AccountValidator.class)
/**
 * @author 2111494
 *
 */
public @interface AgeValidator {
	public String message() default "Age should be between 18 years and 60 years";
	
	
	Class<?>[] groups() default { };

	Class<? extends Payload>[] payload() default { };
}
