package com.cts.bankapplication.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.bankapplication.model.AccountStatement;
import com.cts.bankapplication.models.Transaction;
import com.cts.bankapplication.models.UserAccount;
import com.cts.bankapplication.responce.TransferBalanceRequest;
import com.cts.bankapplication.service.AccountService;
import com.cts.bankapplication.service.AccountServiceImpl;

@RestController
@RequestMapping("/api/account")
public class UserController {

	@Autowired
	private AccountServiceImpl accountService;

	@PostMapping("/create")
	public UserAccount create(@RequestBody UserAccount account) {
		UserAccount acc = accountService.save(account);
		
		return acc;
	}

	@GetMapping("/getAll")
	public List<UserAccount> all() {
		return accountService.findAll();
	}

	@PostMapping("/sendmoney")
	public Transaction sendMoney(@RequestBody TransferBalanceRequest transferBalanceRequest) {

		return accountService.sendMoney(transferBalanceRequest);
	}

	@GetMapping("/statement/{accNumber}")
	public AccountStatement getStatement(@RequestBody @PathVariable("accNumber") String accNumber) {
		return accountService.getStatement(accNumber);

	}

}
