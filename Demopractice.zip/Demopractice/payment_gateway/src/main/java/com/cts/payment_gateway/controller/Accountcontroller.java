package com.cts.payment_gateway.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.payment_gateway.dto.Authrequest;
import com.cts.payment_gateway.entity.Account;
import com.cts.payment_gateway.service.Accountservice;

@RestController
public class Accountcontroller {
	@Autowired
	Accountservice accountservice;

	@PostMapping("/account")
	public Account addaccount(@RequestBody Account account) {
		return this.accountservice.addaccount(account);
	}

	@GetMapping("/account")
	public List<Account> getallaccountinfo() {
		return this.accountservice.getallaccountinfo();
	}

	@GetMapping("/account/{id}")
	public Optional<Account> findaccountbyid(@PathVariable("id") Long id) {
		return this.accountservice.findaccountbyid(id);
	}

	@PutMapping("/account/{id}")
	public Account updateaccountbyid(@RequestBody Account account, @PathVariable("id") Long id) {
		return this.accountservice.updateaccountbyid(account, id);
	}

	@DeleteMapping("/account/{id}")
	public void deleteaccountbyid(@PathVariable("id") Long id) {
		this.accountservice.deleteaccountbyid(id);
	}

	@PostMapping("/account/{id}/deposit")
	public Account deposit(@PathVariable Long id, @RequestBody Map<String, Double> request) {
		Double amount = request.get("amount");
		return accountservice.deposit(id, amount);
	}
	@PostMapping("/account/{id}/withdraw")
	public Account withdraw(@PathVariable Long id, @RequestBody Map<String, Double> request) {
		Double amount = request.get("amount");
		return accountservice.withdraw(id, amount);
	}
	@PostMapping("/authenticate")
	public String authenticateAndGetToken(@RequestBody Authrequest authrequest) {
		return null;
		
	}

}
