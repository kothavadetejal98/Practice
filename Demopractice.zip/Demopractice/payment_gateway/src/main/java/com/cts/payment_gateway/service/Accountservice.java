package com.cts.payment_gateway.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.payment_gateway.entity.Account;
import com.cts.payment_gateway.repo.AccountRepository;

@Service
public class Accountservice {
	@Autowired
	AccountRepository accountrepository;

	public Account addaccount(Account account) {
		return this.accountrepository.save(account);
	}

	public List<Account> getallaccountinfo() {
		return this.accountrepository.findAll();
	}

	public Optional<Account> findaccountbyid(Long id) {
		return this.accountrepository.findById(id);
	}

	public Account updateaccountbyid(Account account, Long id) {
		return this.accountrepository.save(account);
	}

	public void deleteaccountbyid(Long id) {
		this.accountrepository.deleteById(id);
	}

	public Account deposit(Long id, double amount) {
		Account account = findaccountbyid(id).orElseThrow(() -> new RuntimeException("Account not found"));
		account.setBalance(account.getBalance() + amount);
		return accountrepository.save(account);
	}
	

	
	public Account withdraw(Long id,double amount) {
		Account account=findaccountbyid(id).orElseThrow(()->new RuntimeException("Account not found"));
		if(account.getBalance()<amount) {
			throw new RuntimeException("Insufficient funds");
		}
		account.setBalance(account.getBalance() - amount);
		return accountrepository.save(account);
	}
	
	
	

}
