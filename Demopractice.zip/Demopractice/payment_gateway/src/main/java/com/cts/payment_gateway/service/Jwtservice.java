package com.cts.payment_gateway.service;

import org.springframework.stereotype.Component;


@Component
public class Jwtservice {
	
	public String generateToken(String username) {
		return username;
		
	}

}
