package com.cts.payment_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
