package com.cts;

import java.util.function.BiFunction;
import java.util.function.Function;

public class Bifunction {
public static void main(String[] args) {
	BiFunction<String,String,Integer> s=(a,b)->(a+b).length();
	System.out.println(s.apply("Tejal", "Kothavade"));
	
}
}
