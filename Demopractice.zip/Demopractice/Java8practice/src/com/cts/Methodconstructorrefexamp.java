package com.cts;

public class Methodconstructorrefexamp {
	public static void m1() {
		for(int i=0;i<10;i++) {
			System.out.println("child thread");
		}
	
}
	public static void main(String[] args) {
		Runnable r=Methodconstructorrefexamp::m1;
		Thread t=new Thread(r);
		t.start();
		for(int i=0;i<10;i++) {
			System.out.println("main thread");
		}
		
	}

}
