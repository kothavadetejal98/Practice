package com.cts;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Infy {
	public static void main(String[] args) {
		
		//sum of even number
		List<Integer> s=Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		int num1=s.stream().filter(i->i%2==0).mapToInt(Integer::intValue).sum();
		System.out.println(num1);
		
		//print even number and sort
		List<Integer> l=Arrays.asList(1,3,4,5,7,9,2);
		List<Integer> l1=l.stream().filter(i->i%2==0).sorted().collect(Collectors.toList());
		System.out.println(l1);
		
		//max element
		int[] l3= {10,20,30};
		int l2=Arrays.stream(l3).max().getAsInt();
		System.out.println(l2);
		
		//sum of even no
		int l4=l.stream().filter(i->i%2==0).mapToInt(Integer::intValue).sum();
		System.out.println(l4);
		
		//remove duplicate element
		List<Integer> s3=Arrays.asList(1,2,3,4,5,6,7,8,9,10,2,4,5);
		List<Integer> s1=s3.stream().distinct().collect(Collectors.toList());
		System.out.println(s1);
		
		//second largest number
		int[] s7= {6,7,8,9,10};
		int s8=Arrays.stream(s7).boxed() .sorted(Comparator.reverseOrder()) .skip(1) .findFirst() .get();
		System.out.println(s8);
		
		//reverse an array
		List<Integer> s9=Arrays.stream(s7).boxed().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		System.out.println(s9);
		
		//check if array contain specific element
		int[] s10= {1,2,3,4,5};
		boolean s11=Arrays.stream(s10).anyMatch(i->i==4);
		System.out.println(s11);
		
		//average of array element
		double s12=Arrays.stream(s10).average().getAsDouble();
		System.out.println(s12);
		
		
	   //concat two array string
		String[] l15={"a","b"};
		String[] l16={"c","d"};
		
		String[] s13=Stream.concat(Arrays.stream(l15), Arrays.stream(l16)).toArray(String[]::new);
		System.out.println(Arrays.toString(s13));
		
		
		//count occurence of element
		List<String> animal= Arrays.asList("bat","b","bat");
		long count = animal.stream().filter("bat"::equals).count();
		System.out.println(count);
		
		List<Integer> l7=Arrays.asList(80,70,10,20,30);
		Object[] l9=l7.toArray();
		System.out.println(Arrays.toString(l9));
		Integer l8=l7.stream().filter(i->i>10).sorted().min((i1,i2)->i1.compareTo(i2)).get();
		System.out.println(l8);
		
		
		
		
		
		
		
	}

}
