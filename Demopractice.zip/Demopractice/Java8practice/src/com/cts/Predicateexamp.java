package com.cts;

import java.util.function.Predicate;

public class Predicateexamp {
	public static void main(String[] args) {
		Predicate<Integer> l=i->i%2==0;
		System.out.println(l.test(10));
		System.out.println(l.test(15));
		
		
		Predicate<String> k=s1->s1.length()>5;
		System.out.println(k.test("Tejal"));
		
		
	}

}
