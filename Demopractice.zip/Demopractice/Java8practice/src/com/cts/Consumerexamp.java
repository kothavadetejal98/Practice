package com.cts;

import java.util.function.Consumer;

public class Consumerexamp {
	public static void main(String[] args) {
		Consumer<String> c=e-> System.out.println(e);
		c.accept("tejal");
		
				
	}

}
