package com.cts;

public interface Interf {
//	public void m1();
//	public static void main(String[] args) {
//		Interf i=()->System.out.println("hello");
//		i.m1();
//	}
//	public void add(int a,int b);
//	public static void main(String[] args) {
//		Interf i=(a,b)->System.out.println(a+b);
//		i.add(5, 4);
//	}
	
	public void square(int a);
	public static void main(String[] args) {
		Interf i=(a)->System.out.println(a*a);
		i.square(4);
	}

}


