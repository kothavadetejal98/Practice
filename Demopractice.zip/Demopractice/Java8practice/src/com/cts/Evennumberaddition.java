package com.cts;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Evennumberaddition {
	public static void main(String[] args) {
		List<Integer> l=Arrays.asList(1,2,3,4,5,6);
		List<Integer> num1=l.stream().filter(i->i%2==0).collect(Collectors.toList());
		System.out.println();		
		int num=l.stream().filter(i->i%2==0).mapToInt(Integer::intValue).sum();
		System.out.println(num);
		
		List<Integer> a=Arrays.asList(2,4,5,6,7,8);
		List<Integer> num2=a.stream().filter(i->i%2!=0).collect(Collectors.toList());
		System.out.println(num2);
		int sum1=a.stream().filter(i->i%2==0).mapToInt(Integer::intValue).sum();
		System.out.println(sum1);
		
		Predicate<Integer> s=i->i%2==0;
		System.out.println(s.test(9));
		
		Function<Integer,Integer> f=i->i*i*i;
		System.out.println(f.apply(4));
		
		Consumer<String> c=i->System.out.println(i);
		c.accept("dfgg");
		
		
		
		

}
}
