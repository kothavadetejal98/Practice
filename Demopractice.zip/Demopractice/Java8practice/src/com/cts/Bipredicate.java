package com.cts;

import java.util.function.BiPredicate;

public class Bipredicate {
	public static void main(String[] args) {
		BiPredicate<Integer,Integer> p=(a,b)->(a==b);
		System.out.println(" Equal "+p.test(2, 2));
		
	}

}
