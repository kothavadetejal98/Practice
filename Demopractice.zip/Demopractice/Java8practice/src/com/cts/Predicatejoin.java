package com.cts;

import java.util.function.Predicate;

public class Predicatejoin {
	public static void main(String[] args) {
		Predicate<String> length=e->e.length()>5;
		Predicate<String> even=e->e.length()%2==0;
		System.out.println(length.and(even).test("abvcfghhhjhjj"));
	}

}
