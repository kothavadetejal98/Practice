package com.cts;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class Coditas {
public static void main(String[] args) {
	
	List<Integer> s=Arrays.asList(1,2,3,4,5,6,7,8,9,10);
	int num1=s.stream().filter(i->i%2==0).mapToInt(Integer::intValue).sum();
	System.out.println(num1);
	
	
	List<Integer> s1=Arrays.asList(1333,555,66,88);
	List<Integer> num2=s1.stream().filter(i->i%2==0).map(i->i*i).collect(Collectors.toList());
	System.out.println(num2);
	
	List<String> num11=Arrays.asList("gg","hh");
	
	
	List<Integer> m1=Arrays.asList();
	
	List<Integer> num21=Arrays.asList();
	
	List<Integer> l1=Arrays.asList(1,2,3,4);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
	
}

}
