package com.cts;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Comparetoexamp {
	public static void main(String[] args) {
		List<String> s=Arrays.asList("Tejal","Sam","Jpe");
		Collections.sort(s,(e1,e2)->e1.compareTo(e2));
		System.out.println(s);
		s.stream().forEach(System.out::println);
	}
	

}
