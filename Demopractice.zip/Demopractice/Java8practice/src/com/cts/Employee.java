package com.cts;

import java.util.ArrayList;
import java.util.function.Predicate;

public class Employee {
	String name;
	double salary;
	public Employee(String name, double salary) {
		super();
		this.name = name;
		this.salary = salary;
	}
	static class Test{
		public static void main(String[] args) {
			ArrayList<Employee> l=new ArrayList<>();
			l.add(new Employee("Durga",1000));
			l.add(new Employee("Tejal",2000));
			l.add(new Employee("John",500));
			l.add(new Employee("Joe",10000));
			
//			Predicate<Employee> s=e->e.salary>1000;
//			for(Employee s1:l) {
//				if(s.test(s1)) {
//					System.out.println(s1.name+":" +s1.salary);
//				}
//			}
			
			Predicate<Employee> p=e->e.salary%2==0;
			Predicate<Employee> d=e->e.salary>2000;
//			for(Employee p1:l) {
//				if(p.test(p1)) {
//					System.out.println(p1.name);
//				}
//				
//			}
			
			for(Employee s:l) {
				if(p.and(d).test(s)) {
					System.out.println(s.name);
				}
				
			}
		}
	}

}
