package com.cts;

import java.util.function.Function;

public class Functionexamp {
public static void main(String[] args) {
	Function<Integer,Integer> f=i->i*i;
	System.out.println(f.apply(6));
	
	Function<Integer,Integer> f2=i->i*i*i;
	
	Function<String,Integer> f1=i->i.length();
	System.out.println(f1.apply("Tejal"));
	
	System.out.println(f.andThen(f2).apply(2));
}
}
