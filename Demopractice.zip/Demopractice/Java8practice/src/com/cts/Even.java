package com.cts;

import java.util.ArrayList;
import java.util.List;

public class Even {
	public static void main(String[] args) {
		List<Integer> l1 = new ArrayList<>(List.of(0,1,2,3,4,5,6,7,8,9,10));
		 int sum=l1.stream().filter(e->e%2==0).reduce((e1,e2)-> e1+e2).get();
		 int sum1=l1.stream().filter(i->i%2==0).mapToInt(e->e*e*e).sum();
		 System.out.println(sum1);
		 System.out.println(sum);
	}
	
	
	

}
