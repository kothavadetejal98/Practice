package com.cts;

import java.util.stream.Stream;

public class Streamofexamp {
	public static void main(String[] args) {
		Stream s=Stream.of(9,99,999);
		s.forEach(System.out::println);
		
	}

}
