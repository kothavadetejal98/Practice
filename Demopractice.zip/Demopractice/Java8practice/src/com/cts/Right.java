package com.cts;

interface Right {
	
	default void m1() {
		System.out.println("right interface");
	}

}

		
	interface Left{
		default void m1() {
			System.out.println("left interface");
		}
		
		
	}
	
	
	class Test implements Right,Left{
		public void m1() {
			//System.out.println("our own method");
			Left.super.m1();
		}
	public static void main(String[] args) {
			Test t=new Test();
			t.m1();
			
		}
	}
	
	
	
	
