package com.cts;

import java.util.function.Function;
import java.util.function.Predicate;

public class Exercise {
	public static void main(String[] args) {
		//check given number is even or not
		int[] x= {10,20,30,40,50,60,139};
		Predicate<Integer> p=a->a%2==0;
		System.out.println(p.test(4));
		System.out.println(p.test(1));
		for(int x1:x) {
			if(p.test(x1)) {
				System.out.println(x1);
			}
		}
		
		//return sqaure of given number
		Function<Integer,Integer> f=i->i*i;
		System.out.println(f.apply(2));
		
		//return square root of integer
		Function<Integer,Double> s=a->Math.sqrt(a);
		System.out.println(s.apply(4));
	}

}
