package com.cts;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;

public class Dateandtimeexamp {
	public static void main(String[] args) {
		LocalDate today=LocalDate.now();
		System.out.println(today);
		
		LocalTime time=LocalTime.now();
		System.out.println(time);
		
		LocalDateTime dt=LocalDateTime.now();
		System.out.println(dt.plusMonths(8));
		
		LocalDate birthday=LocalDate.of(1998, 10, 28);
		
		Period p=Period.between(today, birthday);
		System.out.println(p);
				
	}

}
