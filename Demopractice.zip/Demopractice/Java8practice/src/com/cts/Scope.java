package com.cts;

public class Scope {
	public static void sum(int a, int b) {
		System.out.println(a + b);
	}

	public static void main(String[] args) {
		Interf1 i = (a, b) -> System.out.println(a + b);
		i.add(4, 36);

		Interf1 i1 = Scope::sum;
		i1.add(3, 4);
	}

}
