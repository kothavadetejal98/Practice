package com.cts;

public interface Interf1 {
	public void add(int a, int b);
	
}

	 
		

	

