package com.cts;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.Set;
import java.util.stream.Collectors;

public class Intermediateoperator {
	public static void main(String[] args) {
		Employee1  e1=new Employee1(1,"sam",23);
		Employee1  e2=new Employee1(2,"Ram",9);
		Employee1  e3=new Employee1(3,"Raj",11);
		Employee1  e4=new Employee1(4,"Gita",18);
		Employee1  e5=new Employee1(4,"Gita",18);
		List<Employee1> e=Arrays.asList(e1,e2,e3,e4,e5);
		
//		List<Integer> e11=e.stream().map(i->i.age).collect(Collectors.toList());
//		System.out.println(e11);
		
		
		 
		
//		List<Integer> arr=Arrays.asList(1,2,3,2,4,3,2,5);
//		List<Integer> arr1=	arr.stream().distinct().collect(Collectors.toList());
//		System.out.println(arr1);
	
//		long count=e.stream().filter(i->i.age>=18).count();
//		System.out.println(count);
		
//		List<Employee1> list=e.stream().filter(i->i.id%2==0).collect(Collectors.toList());
//		System.out.println(list);
//		
//		List<Integer> age=Arrays.asList(23,9,11,18);
//		
//		age.stream().filter(i->i%2==0).map(i->i+i).forEach(i->System.out.println(age));
		
//		List<Integer> num=Arrays.asList(10,20,30,40,110,90);
//		OptionalDouble num1=num.stream().mapToInt(i->i*i).filter(i->i>1000).average();
//		System.out.println(num1);
		
//		List<Integer> num=Arrays.asList(10,20,30,40,110,90);
//		List<Integer> num1=num.stream().sorted().collect(Collectors.toList());
//		System.out.println(num1);
		
//		List<Integer> num=Arrays.asList(10,20,30,40,110,90);
//		Integer num1=num.stream().min((i1,i2)->i1.compareTo(i2)).get();
//		System.out.println(num1);
		
//		List<Integer> num=Arrays.asList(5,2,8,3,1);
//		
//		Integer num1=num.stream().min((i1,i2)->i1.compareTo(i2)).get();
//		Optional<Integer> num2=num.stream().sorted().skip(2).findFirst();
//		System.out.println(num2);
//		System.out.println(num1);

		
		StringBuffer str=new StringBuffer("Tejal");
		System.out.println(str.lastIndexOf("l"));
		
		StringBuilder str1=new StringBuilder("Tejal");
		System.out.println(str1.lastIndexOf("l"));
		
		
		
		
		
		

		
	}

	

}

class Employee1{
	int id;
	String name;
	int age;
	public Employee1() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee1(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}
	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Employee1 [id=" + id + ", name=" + name + ", age=" + age + "]";
	}
	
}