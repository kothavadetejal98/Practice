package com.cts.graphqlpractice.resolver;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.coxautodev.graphql.tools.GraphQLResolver;
import com.cts.graphqlpractice.entity.Subject;
import com.cts.graphqlpractice.response.StudentResponse;
import com.cts.graphqlpractice.response.SubjectResponse;

@Service
public class StudentResponseResolver implements GraphQLResolver<StudentResponse> {
	public List<SubjectResponse> getLearningSubjects(StudentResponse studentResponse) {
		List<SubjectResponse> learningSubjects = new ArrayList<SubjectResponse>();
		if (studentResponse.getStudent().getLearningSubjects() != null) {

			for (Subject subject : studentResponse.getStudent().getLearningSubjects()) {
				learningSubjects.add(new SubjectResponse(subject));
			}

		}
		return learningSubjects;

	}

	public String markswithgrade(StudentResponse studentResponse) {
		return studentResponse.getMarks() + "" + studentResponse.getGrade();
	}
}
