package com.cts.graphqlpractice.response;

import java.util.ArrayList;
import java.util.List;

import com.cts.graphqlpractice.entity.Student;
import com.cts.graphqlpractice.entity.Subject;


public class StudentResponse {
	
	private String id;
	private String name;
	private String marks;
	private String grade;
	private List<SubjectResponse> learningSubjects;
	private Student student;
	private String markswithgrade;
	
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}


	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}


	/**
	 * @return the marks
	 */
	public String getMarks() {
		return marks;
	}


	/**
	 * @param marks the marks to set
	 */
	public void setMarks(String marks) {
		this.marks = marks;
	}


	/**
	 * @return the grade
	 */
	public String getGrade() {
		return grade;
	}


	/**
	 * @param grade the grade to set
	 */
	public void setGrade(String grade) {
		this.grade = grade;
	}


	/**
	 * @return the learningSubjects
	 */
	public List<SubjectResponse> getLearningSubjects() {
		return learningSubjects;
	}


	/**
	 * @param learningSubjects the learningSubjects to set
	 */
	public void setLearningSubjects(List<SubjectResponse> learningSubjects) {
		this.learningSubjects = learningSubjects;
	}


	/**
	 * @return the student
	 */
	public Student getStudent() {
		return student;
	}


	/**
	 * @param student the student to set
	 */
	public void setStudent(Student student) {
		this.student = student;
	}


	public StudentResponse (Student student) {
		this.student=student;
		this.id = student.getId();
		this.name = student.getName();
		this.marks=student.getMarks();
		this.grade=student.getGrade();
		

	}
	
	
	
	
}
