package com.cts.graphqlpractice.response;

import com.cts.graphqlpractice.entity.Student;
import com.cts.graphqlpractice.entity.Subject;

public class SubjectResponse {
private String id;
private String subjectName;
/**
 * @return the id
 */
public String getId() {
	return id;
}
/**
 * @param id the id to set
 */
public void setId(String id) {
	this.id = id;
}
/**
 * @return the subjectName
 */
public String getSubjectName() {
	return subjectName;
}
/**
 * @param subjectName the subjectName to set
 */
public void setSubjectName(String subjectName) {
	this.subjectName = subjectName;
}
public SubjectResponse() {
	super();
	// TODO Auto-generated constructor stub
}
public SubjectResponse(String id, String subjectName) {
	super();
	this.id = id;
	this.subjectName = subjectName;
}
public SubjectResponse (Subject subject) {
	this.id=subject.getId();
	this.subjectName=subject.getSubjectName();
}

}
