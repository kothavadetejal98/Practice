package com.cts.graphqlpractice.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;



@Entity
public class Subject {
	@Id
	private String id;
	private String subjectName;
	
	@ManyToOne
	@JoinColumn(name = "student_id")
	private Student student;

	public Subject() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Subject(String id, String subjectName, Student student) {
		super();
		this.id = id;
		this.subjectName = subjectName;
		this.student = student;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the subjectName
	 */
	public String getSubjectName() {
		return subjectName;
	}

	/**
	 * @param subjectName the subjectName to set
	 */
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	/**
	 * @return the student
	 */
	public Student getStudent() {
		return student;
	}

	/**
	 * @param student the student to set
	 */
	public void setStudent(Student student) {
		this.student = student;
	}
	
	

}
