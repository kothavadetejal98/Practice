package com.cts.graphqlpractice.query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;

import com.cts.graphqlpractice.entity.Student;
import com.cts.graphqlpractice.response.StudentResponse;

import com.cts.graphqlpractice.service.Studentservice;


@Component
public class Query implements GraphQLQueryResolver{
	@Autowired
	Studentservice studentservice;
	
	public String firstquery() {
		return "firstquery";
	}
	
	public String studentData(Student student) {
		return student.getId()+ "" + student.getName() + "" + student.getMarks() + "" + student.getGrade();
	}
	
	public StudentResponse getStudent (String id) {
		return new StudentResponse(studentservice.getStudentById(id));
	}

}
