package com.cts.graphqlpractice.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.cts.graphqlpractice.response.SubjectResponse;


@Entity
public class Student {
	@Id
	private String id;
	private String name;
	private String marks;
	private String grade;
	
	@OneToMany(mappedBy = "student")
	private List<Subject> learningSubjects;
	public Student(String id, String name, String marks, String grade, List<Subject> learningSubjects) {
		super();
		this.id = id;
		this.name = name;
		this.marks = marks;
		this.grade = grade;
		this.learningSubjects = learningSubjects;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the marks
	 */
	public String getMarks() {
		return marks;
	}
	/**
	 * @param marks the marks to set
	 */
	public void setMarks(String marks) {
		this.marks = marks;
	}
	/**
	 * @return the grade
	 */
	public String getGrade() {
		return grade;
	}
	/**
	 * @param grade the grade to set
	 */
	public void setGrade(String grade) {
		this.grade = grade;
	}
	/**
	 * @return the learningSubjects
	 */
	public List<Subject> getLearningSubjects() {
		return learningSubjects;
	}
	/**
	 * @param learningSubjects the learningSubjects to set
	 */
	public void setLearningSubjects(List<Subject> learningSubjects) {
		this.learningSubjects = learningSubjects;
	}
	
	
	
	
	
	

}
