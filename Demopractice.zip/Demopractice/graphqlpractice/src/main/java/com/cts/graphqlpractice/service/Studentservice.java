package com.cts.graphqlpractice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.graphqlpractice.entity.Student;
import com.cts.graphqlpractice.repo.Studentrepo;


@Service
public class Studentservice {
	@Autowired
	Studentrepo studentrepo;

	public Student getStudentById (String id) {
		return studentrepo.findById(id).get();
	}
	
}
