package com.cts.graphqlpractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraphqlpracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
