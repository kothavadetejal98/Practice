package com.cts.contact_service.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.contact_service.entity.Contact;
import com.cts.contact_service.repo.Contactrepo;


@Service
public class Contactservice {
	@Autowired
	private Contactrepo contactrepo;
	
	public List<Contact> getcontactofuser(){
		return this.contactrepo.findAll();
	}
	
	public Contact addcontact(Contact contact) {
		return this.contactrepo.save(contact);
	}
	
	public Optional<Contact> findbyid(Long id) {
		return this.contactrepo.findById(id);
		
	}
	
	

}
