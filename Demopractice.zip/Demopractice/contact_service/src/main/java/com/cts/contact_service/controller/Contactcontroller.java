package com.cts.contact_service.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.contact_service.entity.Contact;
import com.cts.contact_service.service.Contactservice;

@RestController
public class Contactcontroller {
	@Autowired
	private Contactservice contactservice;

	@GetMapping("/contact")
	public List<Contact> getcontactofuser() {
		return this.contactservice.getcontactofuser();
	}

	@PostMapping("/contact")
	public Contact addcontact(@RequestBody Contact contact) {
		return this.contactservice.addcontact(contact);
	}
	@GetMapping("/contact/{id}")
	public Optional<Contact> findbyid(@PathVariable("id") Long id) {
		return this.contactservice.findbyid(id);
	}

}
