package com.customerdetailforbank.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customerdetailforbank.entity.Customerinfo;
import com.customerdetailforbank.repo.Customerrepo;


@Service
public class Customerservice {
	@Autowired
	private Customerrepo customerrepo;

	public Customerinfo adddetail(Customerinfo info) {

		return this.customerrepo.save(info);
	}

	public List<Customerinfo> getalldetail() {
		return this.customerrepo.findAll();
	}

	public Optional<Customerinfo> findbyid(String id) {
		return this.customerrepo.findById(id);
	}

	public void deleteuser(String id) {
		this.customerrepo.deleteById(id);
	}

	public Customerinfo updatebyid(Customerinfo info, String id) {
		return this.customerrepo.save(info);
	}

}
