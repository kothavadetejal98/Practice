package com.customerdetailforbank.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.customerdetailforbank.entity.Customerinfo;
import com.customerdetailforbank.logger.GlobalResources;
import com.customerdetailforbank.service.Customerservice;


@RestController
public class Customercontroller {
private Logger logger =GlobalResources.getLogger(Customercontroller.class);
	
	@Autowired
	Customerservice customerservice;

	@PostMapping("/user")
	public Customerinfo adddetail(@Valid @RequestBody Customerinfo info) {
		String methodName="adddetail()";
		logger.info(methodName + "called");
		return this.customerservice.adddetail(info);
	}

	@GetMapping("/user")
	public List<Customerinfo> getalldetail() {
		String methodName="getalldetail()";
		logger.info(methodName + "called");
		return this.customerservice.getalldetail();
	}

	@GetMapping("/user/{id}")
	public Optional<Customerinfo> findbyid(@PathVariable("id") String id) {
		String methodName="findbyid()";
		logger.info(methodName + "called");
		return this.customerservice.findbyid(id);
	}

	@DeleteMapping("/user/{id}")
	public void deleteuser(@PathVariable("id") String id) {
		String methodName="deleteuser()";
		logger.info(methodName + "called");
         this.customerservice.deleteuser(id);
	}
	@PutMapping("/user/{id}")
	public Customerinfo updatebyid(@Valid @RequestBody Customerinfo info,@PathVariable("id") String id) {
		String methodName="updatebyid()";
		logger.info(methodName + "called");
		return this.customerservice.updatebyid(info, id);
	}

}
