package com.customerdetailforbank.entity;

import java.math.BigDecimal;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "customerinfo")
public class Customerinfo {
	@Id
	@Column(name = "cust_id")
	private String id;
	@NotNull(message = "User name must not contain any numbers & special character")

	private String customername;
	@NotNull(message = "Account number must have 8 to 12 digit")

	private String accountnumber;
	@NotNull(message = "Enter valid pan number")
	@Pattern(message = "pan number should have 10 character", regexp = "[A-Z]{5}[0-9]{4}[A-Z]{1}")
	private String pannumber;
	@NotNull
	private String accounttype;
	@NotNull
	private String accountstatus;

	private BigDecimal accountbalance;
	@Email
	@NotNull(message = "Enter valid email")
	private String email;
//	@OneToOne(targetEntity=Mobilenumber.class,cascade=CascadeType.ALL)
//	private Mobilenumber mobilenumber;
	@ElementCollection

	private Map<String, String> mobilenumber;

	public Customerinfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customerinfo(String id,
			@NotNull(message = "User name must not contain any numbers & special character") String customername,
			@NotNull(message = "Account number must have 8 to 12 digit") String accountnumber,
			@NotNull(message = "Enter valid pan number") @Pattern(message = "pan number should have 10 character", regexp = "[A-Z]{5}[0-9]{4}[A-Z]{1}") String pannumber,
			@NotNull String accounttype, @NotNull String accountstatus, BigDecimal accountbalance,
			@Email @NotNull(message = "Enter valid email") String email, Map<String, String> mobilenumber) {
		super();
		this.id = id;
		this.customername = customername;
		this.accountnumber = accountnumber;
		this.pannumber = pannumber;
		this.accounttype = accounttype;
		this.accountstatus = accountstatus;
		this.accountbalance = accountbalance;
		this.email = email;
		this.mobilenumber = mobilenumber;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}

	public String getPannumber() {
		return pannumber;
	}

	public void setPannumber(String pannumber) {
		this.pannumber = pannumber;
	}

	public String getAccounttype() {
		return accounttype;
	}

	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}

	public String getAccountstatus() {
		return accountstatus;
	}

	public void setAccountstatus(String accountstatus) {
		this.accountstatus = accountstatus;
	}

	public BigDecimal getAccountbalance() {
		return accountbalance;
	}

	public void setAccountbalance(BigDecimal accountbalance) {
		this.accountbalance = accountbalance;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Map<String, String> getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(Map<String, String> mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	@Override
	public String toString() {
		return "Customerinfo [id=" + id + ", customername=" + customername + ", accountnumber=" + accountnumber
				+ ", pannumber=" + pannumber + ", accounttype=" + accounttype + ", accountstatus=" + accountstatus
				+ ", accountbalance=" + accountbalance + ", email=" + email + ", mobilenumber=" + mobilenumber + "]";
	}


}
