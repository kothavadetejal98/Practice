package com.cts.Employee.Management.App.Poc.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cts.Employee.Management.App.Poc.entity.Employeedetails;
import com.cts.Employee.Management.App.Poc.repo.Employeerepo;

@Service
public class Employeeservice {
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	Employeerepo repo;

	public Employeedetails adddetail(Employeedetails employee) {
		employee.setPassword(passwordEncoder.encode(employee.getPassword()));
		employee.setRole("ROLE_"+employee.getRole().toUpperCase());
		return this.repo.save(employee);
	}

	public List<Employeedetails> getallemployeedetail() {
		return this.repo.findAll();

	}

	public Employeedetails updatedetails(Employeedetails employee, int id) {
		return this.repo.save(employee);
	}

	public Optional<Employeedetails> findbyid(int id) {
		return this.repo.findById(id);
	}

	public List<Employeedetails> findbyname(String name) {
		return this.repo.findByNameEquals(name);
	}

	public void deleteemployeebyid(int id) {
		repo.deleteById(id);
	}

}
