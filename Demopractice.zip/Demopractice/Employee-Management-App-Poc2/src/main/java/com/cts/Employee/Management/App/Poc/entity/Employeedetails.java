package com.cts.Employee.Management.App.Poc.entity;

import java.time.LocalDate;
import java.util.Collection;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonFormat;




@Entity
@Table(name = "employeedetails")
public class Employeedetails implements UserDetails{
	@Id
	@NotNull(message = "Please enter empid ")
    private int empid;
	
	@NotNull(message = "Please enter name ")
	private String name;
	
	
	@Email(message = "enter valid email")
	private String email;
	
	@JsonFormat(pattern = "MM/dd/yyyy")
	@NotNull(message = "Please enter dateofjoining ")
	private LocalDate dateofjoining;
	
	@Pattern(regexp = "[6-9]{1}[0-9]{9}", message = "enter valid contactnumber")
	private String contactnumber;
	
	
	private String  password;
	@JsonFormat(pattern = "MM/dd/yyyy")
	private LocalDate dateofpassword;
	
	private String role;
	
	
	
	


	public Employeedetails(@NotNull(message = "Please enter empid ") int empid,
			@NotNull(message = "Please enter name ") String name, @Email(message = "enter valid email") String email,
			@NotNull(message = "Please enter dateofjoining ") LocalDate dateofjoining,
			@Pattern(regexp = "[6-9]{1}[0-9]{9}", message = "enter valid contactnumber") String contactnumber,
			String password, LocalDate dateofpassword, String role) {
		super();
		this.empid = empid;
		this.name = name;
		this.email = email;
		this.dateofjoining = dateofjoining;
		this.contactnumber = contactnumber;
		this.password = password;
		this.dateofpassword = dateofpassword;
		this.role = role;
	}


	public Employeedetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public LocalDate getDateofjoining() {
		return dateofjoining;
	}
	public void setDateofjoining(LocalDate dateofjoining) {
		this.dateofjoining = dateofjoining;
	}
	public String getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}
	
	
	
	
	
	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public LocalDate getDateofpassword() {
		return dateofpassword;
	}


	public void setDateofpassword(LocalDate dateofpassword) {
		this.dateofpassword = dateofpassword;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	@Override
	public String toString() {
		return "Employeedetails [empid=" + empid + ", name=" + name + ", email=" + email + ", dateofjoining="
				+ dateofjoining + ", contactnumber=" + contactnumber + ", password=" + password + ", dateofpassword="
				+ dateofpassword + ", role=" + role + "]";
	}


	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		SimpleGrantedAuthority simpleGrantAuthority=new SimpleGrantedAuthority(this.role);
		return List.of(simpleGrantAuthority);
	}


	

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		
		return this.email;
	}


	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}


	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}


	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}


	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}


	
	
	
	
	
	
	

	



	

}
