package com.cts.Employee.Management.App.Poc.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cts.Employee.Management.App.Poc.entity.Employeedetails;
import com.cts.Employee.Management.App.Poc.repo.Employeerepo;



@Service
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	public Employeerepo employeerepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		//load user from database
		System.out.println(username);
		 Employeedetails employee = employeerepo.findByEmail(username).orElseThrow(()->new RuntimeException("user not found"));
		return employee;
	}
	
	

}
