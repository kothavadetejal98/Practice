package com.cts.Employee.Management.App.Poc.Filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;




@Component
public class JwtFilter extends OncePerRequestFilter {

	@Autowired
	private com.cts.Employee.Management.App.Poc.Jwt.JwtHelper jwtHelper;
	
	@Autowired
	private UserDetailsService userDetailsService;
	
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String requestHeader = request.getHeader("Authorization");
		System.out.println(requestHeader);
		String username = null;
        String token = null;
        if (requestHeader != null && requestHeader.startsWith("Bearer")) {
        	token = requestHeader.substring(7);
        	username = this.jwtHelper.getUsernameFromToken(token);
        	System.out.println(username);
        }
        	if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
        		UserDetails userDetails = userDetailsService.loadUserByUsername(username);
        		System.out.println(userDetails);
        		Boolean validateToken = this.jwtHelper.validateToken(token, userDetails);
        		 if (validateToken) {

                     //set the authentication
                     UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                     authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                     SecurityContextHolder.getContext().setAuthentication(authentication);

        		 }
        	}

        filterChain.doFilter(request, response);
	}

}
